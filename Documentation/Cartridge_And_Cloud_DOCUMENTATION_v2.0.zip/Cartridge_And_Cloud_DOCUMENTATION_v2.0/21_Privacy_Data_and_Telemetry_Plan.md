# 21 Privacy Data and Telemetry Plan

> **Metadatos normativos v2.0**  
> `document_version:` 2.0  
> `project_version:` 0.0.26  
> `last_reviewed:` 2026-07-17  
> `status:` APPROVED / IMPLEMENTED / VALIDATED / CONSOLIDATED BASELINE  
> `lifecycle:` LIVING DOCUMENT

---
title: "Cartridge & Cloud — Privacy, Data and Telemetry Plan"
subtitle: "Plan consolidado de privacidad, datos locales, soporte, plataforma y futura telemetría"
author: "VRM Games / Blas Luis Rocha González"
date: "2026-07-06"
lang: es-ES
document_version: "2.0"
project_version: "0.0.26"
status: "APPROVED / IMPLEMENTED / VALIDATED / CONSOLIDATED BASELINE"
---

## Cartridge & Cloud — Privacy, Data and Telemetry Plan

**Proyecto:** Cartridge & Cloud  
**Desarrollador:** VRM Games / Blas Luis Rocha González  
**Plataforma prevista:** PC / Steam  
**Motor:** Unity 6.3 LTS `6000.3.18f1` / URP `17.3.0`  
**Versión observada:** `0.0.26`  
**Fecha de verificación normativa y de fuentes:** 1 de julio de 2026  
**Estado:** Sprints 0–15 `CLOSED / PASS`; Sprint 16 `COMPLETED / PASS`; Sprint 17 `APPROVED / IMPLEMENTED / VALIDATED / CLOSED`; H6 `APPROVED / IMPLEMENTED / VALIDATED / CLOSED`  
**Estado de datos:** `LOCAL-FIRST`; telemetría propia, backend, Cloud, analytics y crash reporting externo `NOT OPEN`

> **Aviso:** este documento es un plan técnico, operativo y de gobernanza. No sustituye asesoramiento jurídico profesional ni una evaluación concreta de la autoridad o del responsable del tratamiento. Antes de publicar una política, activar un SDK, transferir datos o tratar datos de menores debe realizarse revisión jurídica y de seguridad adecuada al caso.

### Resumen ejecutivo

Cartridge & Cloud puede mantener una primera versión **sin telemetría propia**. El juego observado es offline, no integra Steamworks, no dispone de backend, cuenta propia, servidor, newsletter, website analytics, ticketing o crash reporting externo. El save y las preferencias permanecen localmente en el equipo del jugador. Esta reducción de superficie es una decisión favorable que debe preservarse hasta que una necesidad real justifique abrir un nuevo flujo.

La ausencia de SDK no equivale a “cero datos” en sentido absoluto. Steam y las herramientas de desarrollo mantienen sus propios tratamientos; UnityConnect contiene configuración de servicios y Engine Diagnostics; `Player.log`, saves, screenshots o dumps pueden llegar al estudio si el jugador los remite voluntariamente; una futura web o email de soporte también trataría datos. Este plan registra esas fronteras y evita atribuir al estudio datos que Valve procesa por su cuenta.

La guía específica de AEPD y Autoridad Belga de junio de 2026 advierte que la telemetría y las inferencias en videojuegos pueden individualizar a jugadores y ser invisibles para ellos. Por ello, cualquier futura instrumentación debe partir de finalidad, minimización, transparencia, roles, base jurídica, retención, seguridad y capacidad de intervenir. La telemetría no es un requisito de H6 ni una condición para lanzar.

| Superficie | Estado observado | Política |
|---|---|---|
| Save | local, schema 2 (`CurrentSchemaVersion = 2`), primary/backup/temp/recovery | no se transmite salvo acción voluntaria o Cloud futura |
| PlayerPrefs | volúmenes y ocultación de paredes | local, no sensible |
| Player.log | local | soporte voluntario, redacción y retención limitada |
| UGS Analytics | no integrado; setting desactivado | `NOT OPEN` |
| Unity Cloud Diagnostics | desactivado | `NOT OPEN` |
| Engine Diagnostics | setting observado habilitado | revisar editor/herramienta y términos; no inferir player telemetry |
| Steamworks / SteamID | no integrado | `NOT OPEN` |
| Steam Cloud | no integrado | `NOT OPEN` |
| Crash SDK externo | no integrado | `NOT OPEN` |
| Soporte/ticketing | no existe | diseñar antes de publicación |
| Website/cookies/newsletter | no documentados | comenzar sin tracking |

### Convenciones de estado

| Estado | Significado |
|---|---|
| `CURRENT` | Evidencia observada en código, settings o documentos vigentes. |
| `LOCAL` | Dato permanece en el dispositivo y no lo recibe VRM Games por defecto. |
| `VOLUNTARY SUPPORT` | El usuario decide enviar un archivo o información para resolver una incidencia. |
| `PLANNED` | Diseño autorizado, todavía no implementado. |
| `NOT OPEN` | No se permite implementar ni comunicar la feature sin nuevo gate. |
| `BLOCKED` | Existe una condición explícita que impide avanzar. |
| `HISTORICAL` | Se conserva por genealogía, no gobierna el runtime actual. |

## 0. Propósito, alcance y autoridad

Este capítulo pertenece al bloque **Gobernanza y estado**. Su objetivo es convertir **propósito, alcance y autoridad** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe un plan histórico dedicado de privacidad; las baselines exigían política solo cuando hubiera recogida, y trataban telemetría, Cloud y plataforma como sistemas futuros.

**Regla de Cartridge & Cloud.** Toda decisión debe distinguir evidencia actual, intención histórica y sistema futuro. La ausencia de SDK no autoriza a afirmar que no existe ningún tratamiento externo de plataforma o herramienta.

**Procedimiento operativo.**
1. Inventariar fuentes y responsables.
2. Registrar estado CURRENT/PLANNED/NOT OPEN.
3. Separar datos locales, datos enviados y datos de terceros.
4. Asignar owner y gate.
5. Registrar específicamente el impacto de `Propósito, alcance y autoridad` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Documento versionado, hashes, decision log y mapa de autoridad.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004`.

## 1. Genealogía histórica

Este capítulo pertenece al bloque **Gobernanza y estado**. Su objetivo es convertir **genealogía histórica** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Las baselines v0.3/v0.4 exigían “política de privacidad si se recopilan datos”; v0.5/v0.6 añadieron privacidad al gate previo a Steam. Los GDD hablaban de telemetría interna y analytics como visión, mientras Setup y Sprints excluyeron Analytics y Cloud Save. Este es el primer plan dedicado.

**Regla de Cartridge & Cloud.** La genealogía se preserva sin reinterpretar la palabra “telemetría interna” como integración real. Toda referencia futura permanece VISION/NOT OPEN.

**Procedimiento operativo.**
1. Inventariar fuentes y responsables.
2. Registrar estado CURRENT/PLANNED/NOT OPEN.
3. Separar datos locales, datos enviados y datos de terceros.
4. Asignar owner y gate.
5. Registrar específicamente el impacto de `Genealogía histórica` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Tabla de versiones, citas de fuente, hash y clasificación CURRENT/HISTORICAL/VISION.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004`.

Los adjuntos voluntarios se consideran potencialmente identificables, se almacenan fuera del repositorio y se vinculan a un ticket mediante un ID interno, no mediante el nombre público del jugador.

## 2. Estado actual del proyecto

Este capítulo pertenece al bloque **Gobernanza y estado**. Su objetivo es convertir **estado actual del proyecto** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Aplicación `0.0.26`, Windows x64, Unity `6000.3.18f1`. No se encontraron Steamworks, UGS Analytics runtime, SDK externo de analytics/crash, HTTP de producto, Cloud o device fingerprinting. Unity Analytics, Cloud Diagnostics, Ads, Purchasing y Performance Reporting aparecen desactivados en `UnityConnectSettings.asset`; Engine Diagnostics está configurado, lo que requiere revisión separada de editor/herramienta.

**Regla de Cartridge & Cloud.** Se puede publicar una primera versión sin telemetría propia. Antes de afirmar “cero datos”, se verifican build, plataforma, herramientas, soporte y website.

**Procedimiento operativo.**
1. Inventariar fuentes y responsables.
2. Registrar estado CURRENT/PLANNED/NOT OPEN.
3. Separar datos locales, datos enviados y datos de terceros.
4. Asignar owner y gate.
5. Registrar específicamente el impacto de `Estado actual del proyecto` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Escaneo de código/paquetes/settings, build externa y captura de tráfico controlada.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004`.

## 3. Principios de privacidad

Este capítulo pertenece al bloque **Principios y accountability**. Su objetivo es convertir **principios de privacidad** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** La arquitectura actual es predominantemente offline y local, lo que reduce la superficie, pero soporte, Steamworks y futuros SDK pueden crear tratamientos.

**Regla de Cartridge & Cloud.** Licititud, lealtad, transparencia, finalidad, minimización, exactitud, conservación limitada, seguridad y responsabilidad proactiva se aplican desde diseño.

**Procedimiento operativo.**
1. Definir finalidad concreta.
2. Evaluar necesidad y proporcionalidad.
3. Eliminar campos “por si acaso”.
4. Documentar medidas y revisar cambios.
5. Registrar específicamente el impacto de `Principios de privacidad` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Ficha de tratamiento, revisión de riesgo, ADR y criterio de aceptación.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007`.

La clasificación aplica contexto y riesgo de inferencia. No se recopila edad exacta, salud, biometría, chat o categorías especiales para “mejorar segmentación”.

## 4. Privacidad por diseño

Este capítulo pertenece al bloque **Principios y accountability**. Su objetivo es convertir **privacidad por diseño** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El proyecto tiene una ventaja estructural: gameplay offline, sin cuenta propia ni red. Esa arquitectura debe considerarse un requisito, no una ausencia accidental.

**Regla de Cartridge & Cloud.** Cualquier feature que introduzca red, identidad o SDK debe demostrar por qué no puede resolverse localmente o mediante reporting agregado de Steam.

**Procedimiento operativo.**
1. Definir finalidad concreta.
2. Evaluar necesidad y proporcionalidad.
3. Eliminar campos “por si acaso”.
4. Documentar medidas y revisar cambios.
5. Registrar específicamente el impacto de `Privacidad por diseño` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** ADR, data-flow antes/después, threat model, minimization review y decisión.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007`.

## 5. Minimización

Este capítulo pertenece al bloque **Principios y accountability**. Su objetivo es convertir **minimización** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El save actual necesita estado del juego, no identidad real. Los PlayerPrefs observados guardan volumen y ocultación de paredes. Ninguna métrica futura debe añadir nombre, email, SteamID o dispositivo si basta con un agregado.

**Regla de Cartridge & Cloud.** Se prohíben campos libres y atributos “nice to have”. Los schemas se podan periódicamente y se retiran campos sin consumidor.

**Procedimiento operativo.**
1. Definir finalidad concreta.
2. Evaluar necesidad y proporcionalidad.
3. Eliminar campos “por si acaso”.
4. Documentar medidas y revisar cambios.
5. Registrar específicamente el impacto de `Minimización` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Data dictionary con justificación por campo y reporte de campos eliminados.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007`.

## 6. Limitación de finalidad

Este capítulo pertenece al bloque **Principios y accountability**. Su objetivo es convertir **limitación de finalidad** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** La arquitectura actual es predominantemente offline y local, lo que reduce la superficie, pero soporte, Steamworks y futuros SDK pueden crear tratamientos.

**Regla de Cartridge & Cloud.** Licititud, lealtad, transparencia, finalidad, minimización, exactitud, conservación limitada, seguridad y responsabilidad proactiva se aplican desde diseño.

**Procedimiento operativo.**
1. Definir finalidad concreta.
2. Evaluar necesidad y proporcionalidad.
3. Eliminar campos “por si acaso”.
4. Documentar medidas y revisar cambios.
5. Registrar específicamente el impacto de `Limitación de finalidad` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Ficha de tratamiento, revisión de riesgo, ADR y criterio de aceptación.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007`.

## 7. Exactitud

Este capítulo pertenece al bloque **Principios y accountability**. Su objetivo es convertir **exactitud** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** La arquitectura actual es predominantemente offline y local, lo que reduce la superficie, pero soporte, Steamworks y futuros SDK pueden crear tratamientos.

**Regla de Cartridge & Cloud.** Licititud, lealtad, transparencia, finalidad, minimización, exactitud, conservación limitada, seguridad y responsabilidad proactiva se aplican desde diseño.

**Procedimiento operativo.**
1. Definir finalidad concreta.
2. Evaluar necesidad y proporcionalidad.
3. Eliminar campos “por si acaso”.
4. Documentar medidas y revisar cambios.
5. Registrar específicamente el impacto de `Exactitud` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Ficha de tratamiento, revisión de riesgo, ADR y criterio de aceptación.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007`.

## 8. Retención

Este capítulo pertenece al bloque **Principios y accountability**. Su objetivo es convertir **retención** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** La arquitectura actual es predominantemente offline y local, lo que reduce la superficie, pero soporte, Steamworks y futuros SDK pueden crear tratamientos.

**Regla de Cartridge & Cloud.** Licititud, lealtad, transparencia, finalidad, minimización, exactitud, conservación limitada, seguridad y responsabilidad proactiva se aplican desde diseño.

**Procedimiento operativo.**
1. Definir finalidad concreta.
2. Evaluar necesidad y proporcionalidad.
3. Eliminar campos “por si acaso”.
4. Documentar medidas y revisar cambios.
5. Registrar específicamente el impacto de `Retención` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Ficha de tratamiento, revisión de riesgo, ADR y criterio de aceptación.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007`.

El borrado cubre índices, objetos primarios y copias operativas; los backups tienen una ventana documentada y no se restauran para reactivar datos que debían eliminarse.

## 9. Seguridad

Este capítulo pertenece al bloque **Principios y accountability**. Su objetivo es convertir **seguridad** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** La arquitectura actual es predominantemente offline y local, lo que reduce la superficie, pero soporte, Steamworks y futuros SDK pueden crear tratamientos.

**Regla de Cartridge & Cloud.** Licititud, lealtad, transparencia, finalidad, minimización, exactitud, conservación limitada, seguridad y responsabilidad proactiva se aplican desde diseño.

**Procedimiento operativo.**
1. Definir finalidad concreta.
2. Evaluar necesidad y proporcionalidad.
3. Eliminar campos “por si acaso”.
4. Documentar medidas y revisar cambios.
5. Registrar específicamente el impacto de `Seguridad` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Ficha de tratamiento, revisión de riesgo, ADR y criterio de aceptación.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007`.

Los controles incluyen least privilege, MFA, segregación de entornos, inventario de secretos, rotación, logs de acceso, restauración y simulacros, con evidencia fechada.

## 10. Transparencia

Este capítulo pertenece al bloque **Principios y accountability**. Su objetivo es convertir **transparencia** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** La arquitectura actual es predominantemente offline y local, lo que reduce la superficie, pero soporte, Steamworks y futuros SDK pueden crear tratamientos.

**Regla de Cartridge & Cloud.** Licititud, lealtad, transparencia, finalidad, minimización, exactitud, conservación limitada, seguridad y responsabilidad proactiva se aplican desde diseño.

**Procedimiento operativo.**
1. Definir finalidad concreta.
2. Evaluar necesidad y proporcionalidad.
3. Eliminar campos “por si acaso”.
4. Documentar medidas y revisar cambios.
5. Registrar específicamente el impacto de `Transparencia` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Ficha de tratamiento, revisión de riesgo, ADR y criterio de aceptación.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007`.

La información se presenta por capas: resumen contextual en el punto de recogida, detalle completo accesible y versión archivada. El texto no usa finalidades vagas como “mejorar la experiencia” sin explicar datos y uso.

## 11. Responsabilidad

Este capítulo pertenece al bloque **Principios y accountability**. Su objetivo es convertir **responsabilidad** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** La arquitectura actual es predominantemente offline y local, lo que reduce la superficie, pero soporte, Steamworks y futuros SDK pueden crear tratamientos.

**Regla de Cartridge & Cloud.** Licititud, lealtad, transparencia, finalidad, minimización, exactitud, conservación limitada, seguridad y responsabilidad proactiva se aplican desde diseño.

**Procedimiento operativo.**
1. Definir finalidad concreta.
2. Evaluar necesidad y proporcionalidad.
3. Eliminar campos “por si acaso”.
4. Documentar medidas y revisar cambios.
5. Registrar específicamente el impacto de `Responsabilidad` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Ficha de tratamiento, revisión de riesgo, ADR y criterio de aceptación.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007`.

## 12. Datos personales

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **datos personales** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El save contiene estado de juego, IDs sintéticos y timestamps; no contiene nombres humanos, email, SteamID ni datos de dispositivo observados. Logs y archivos de soporte podrían contener datos incidentales.

**Regla de Cartridge & Cloud.** La clasificación depende de identificabilidad y contexto, no del nombre del campo. Un ID persistente, una IP o un patrón conductual pueden ser datos personales.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Datos personales` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Diccionario de datos, ejemplo de payload y matriz de acceso.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

| Tipo | Ejemplo | Estado actual |
|---|---|---|
| Identificador directo | email de soporte | no existe / futuro |
| Identificador de plataforma | SteamID | no recogido |
| Identificador indirecto | IP, device fingerprint | no recogido por juego |
| Datos conductuales | secuencia de acciones por jugador | no recogida remotamente |
| Datos aportados | log/save/screenshot | solo soporte voluntario futuro |

## 13. Datos no personales

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **datos no personales** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El save contiene estado de juego, IDs sintéticos y timestamps; no contiene nombres humanos, email, SteamID ni datos de dispositivo observados. Logs y archivos de soporte podrían contener datos incidentales.

**Regla de Cartridge & Cloud.** La clasificación depende de identificabilidad y contexto, no del nombre del campo. Un ID persistente, una IP o un patrón conductual pueden ser datos personales.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Datos no personales` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Diccionario de datos, ejemplo de payload y matriz de acceso.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

Un dato agregado puede ser no personal solo si no permite identificar razonablemente a una persona. Conteos globales con umbrales y sin cohortes pequeñas pueden acercarse a esa condición; un ID hashado, un evento individual o una secuencia única no se clasifican automáticamente como no personales.

## 14. Pseudonimización

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **pseudonimización** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Un hash, SteamID transformado o identificador estable sigue siendo dato personal cuando puede vincularse o combinarse. La seudonimización reduce riesgo, pero no saca el tratamiento del RGPD.

**Regla de Cartridge & Cloud.** La tabla de reidentificación, salt o secreto se separa, limita y rota. No se usa el mismo ID entre títulos/campañas sin necesidad.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Pseudonimización` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Diseño criptográfico revisado, key custody y prueba de rotación/borrado.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

## 15. Anonimización

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **anonimización** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Solo se denomina anónimo a un conjunto cuando la identificación ya no es razonablemente posible considerando datos auxiliares y singularidad conductual. Borrar el nombre no basta.

**Regla de Cartridge & Cloud.** Los agregados aplican umbrales, generalización y revisión de unicidad. Si persiste linkability, se trata como dato personal.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Anonimización` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Anonymisation assessment, test de singularidad y decisión firmada.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

## 16. Identificadores

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **identificadores** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El save contiene estado de juego, IDs sintéticos y timestamps; no contiene nombres humanos, email, SteamID ni datos de dispositivo observados. Logs y archivos de soporte podrían contener datos incidentales.

**Regla de Cartridge & Cloud.** La clasificación depende de identificabilidad y contexto, no del nombre del campo. Un ID persistente, una IP o un patrón conductual pueden ser datos personales.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Identificadores` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Diccionario de datos, ejemplo de payload y matriz de acceso.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

## 17. Datos técnicos

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **datos técnicos** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El save contiene estado de juego, IDs sintéticos y timestamps; no contiene nombres humanos, email, SteamID ni datos de dispositivo observados. Logs y archivos de soporte podrían contener datos incidentales.

**Regla de Cartridge & Cloud.** La clasificación depende de identificabilidad y contexto, no del nombre del campo. Un ID persistente, una IP o un patrón conductual pueden ser datos personales.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Datos técnicos` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Diccionario de datos, ejemplo de payload y matriz de acceso.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

| Campo técnico | Necesidad potencial | Riesgo | Política |
|---|---|---|---|
| versión/build | reproducir defectos | bajo | permitido en soporte |
| OS | compatibilidad | medio | versión general, no serial |
| GPU/CPU | rendimiento | medio | modelo, no device ID |
| resolución | UI/performance | bajo | bucket |
| branch/manifest | diagnóstico | bajo | interno/soporte |
| IP | transporte/seguridad | alto | no almacenar por defecto |

## 18. Datos de dispositivo

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **datos de dispositivo** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El save contiene estado de juego, IDs sintéticos y timestamps; no contiene nombres humanos, email, SteamID ni datos de dispositivo observados. Logs y archivos de soporte podrían contener datos incidentales.

**Regla de Cartridge & Cloud.** La clasificación depende de identificabilidad y contexto, no del nombre del campo. Un ID persistente, una IP o un patrón conductual pueden ser datos personales.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Datos de dispositivo` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Diccionario de datos, ejemplo de payload y matriz de acceso.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

## 19. Sistema operativo

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **sistema operativo** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El save contiene estado de juego, IDs sintéticos y timestamps; no contiene nombres humanos, email, SteamID ni datos de dispositivo observados. Logs y archivos de soporte podrían contener datos incidentales.

**Regla de Cartridge & Cloud.** La clasificación depende de identificabilidad y contexto, no del nombre del campo. Un ID persistente, una IP o un patrón conductual pueden ser datos personales.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Sistema operativo` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Diccionario de datos, ejemplo de payload y matriz de acceso.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

## 20. Hardware

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **hardware** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El save contiene estado de juego, IDs sintéticos y timestamps; no contiene nombres humanos, email, SteamID ni datos de dispositivo observados. Logs y archivos de soporte podrían contener datos incidentales.

**Regla de Cartridge & Cloud.** La clasificación depende de identificabilidad y contexto, no del nombre del campo. Un ID persistente, una IP o un patrón conductual pueden ser datos personales.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Hardware` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Diccionario de datos, ejemplo de payload y matriz de acceso.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

## 21. Resolución

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **resolución** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El save contiene estado de juego, IDs sintéticos y timestamps; no contiene nombres humanos, email, SteamID ni datos de dispositivo observados. Logs y archivos de soporte podrían contener datos incidentales.

**Regla de Cartridge & Cloud.** La clasificación depende de identificabilidad y contexto, no del nombre del campo. Un ID persistente, una IP o un patrón conductual pueden ser datos personales.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Resolución` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Diccionario de datos, ejemplo de payload y matriz de acceso.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

## 22. Idioma

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **idioma** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El save contiene estado de juego, IDs sintéticos y timestamps; no contiene nombres humanos, email, SteamID ni datos de dispositivo observados. Logs y archivos de soporte podrían contener datos incidentales.

**Regla de Cartridge & Cloud.** La clasificación depende de identificabilidad y contexto, no del nombre del campo. Un ID persistente, una IP o un patrón conductual pueden ser datos personales.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Idioma` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Diccionario de datos, ejemplo de payload y matriz de acceso.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

## 23. Versión

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **versión** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El save contiene estado de juego, IDs sintéticos y timestamps; no contiene nombres humanos, email, SteamID ni datos de dispositivo observados. Logs y archivos de soporte podrían contener datos incidentales.

**Regla de Cartridge & Cloud.** La clasificación depende de identificabilidad y contexto, no del nombre del campo. Un ID persistente, una IP o un patrón conductual pueden ser datos personales.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Versión` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Diccionario de datos, ejemplo de payload y matriz de acceso.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

## 24. Branch

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **branch** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El save contiene estado de juego, IDs sintéticos y timestamps; no contiene nombres humanos, email, SteamID ni datos de dispositivo observados. Logs y archivos de soporte podrían contener datos incidentales.

**Regla de Cartridge & Cloud.** La clasificación depende de identificabilidad y contexto, no del nombre del campo. Un ID persistente, una IP o un patrón conductual pueden ser datos personales.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Branch` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Diccionario de datos, ejemplo de payload y matriz de acceso.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

## 25. Manifest ID

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **manifest id** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El save contiene estado de juego, IDs sintéticos y timestamps; no contiene nombres humanos, email, SteamID ni datos de dispositivo observados. Logs y archivos de soporte podrían contener datos incidentales.

**Regla de Cartridge & Cloud.** La clasificación depende de identificabilidad y contexto, no del nombre del campo. Un ID persistente, una IP o un patrón conductual pueden ser datos personales.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Manifest ID` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Diccionario de datos, ejemplo de payload y matriz de acceso.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

Los informes de Steam se tratan como una fuente separada: el estudio registra qué campos recibe, si son agregados y quién tiene permiso; no infiere acceso a datos individuales por el mero hecho de usar Steamworks.

## 26. App ID

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **app id** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El save contiene estado de juego, IDs sintéticos y timestamps; no contiene nombres humanos, email, SteamID ni datos de dispositivo observados. Logs y archivos de soporte podrían contener datos incidentales.

**Regla de Cartridge & Cloud.** La clasificación depende de identificabilidad y contexto, no del nombre del campo. Un ID persistente, una IP o un patrón conductual pueden ser datos personales.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `App ID` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Diccionario de datos, ejemplo de payload y matriz de acceso.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

Los informes de Steam se tratan como una fuente separada: el estudio registra qué campos recibe, si son agregados y quién tiene permiso; no infiere acceso a datos individuales por el mero hecho de usar Steamworks.

## 27. Steam ID

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **steam id** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No se recoge actualmente. Una futura autenticación Steam puede entregar SteamID y permitir vincular propiedad, cuenta o backend. SteamID es un identificador persistente y no debe tratarse como anónimo.

**Regla de Cartridge & Cloud.** No se obtiene ni almacena SteamID salvo feature aprobada. Si se almacena, se implementan acceso/supresión y seguimiento de cuentas eliminadas cuando sea aplicable.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Steam ID` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Integración Steam, RAT, mapping, delete workflow y prueba con cuenta eliminada.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

Los informes de Steam se tratan como una fuente separada: el estudio registra qué campos recibe, si son agregados y quién tiene permiso; no infiere acceso a datos individuales por el mero hecho de usar Steamworks.

## 28. Nombre visible

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **nombre visible** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El save contiene estado de juego, IDs sintéticos y timestamps; no contiene nombres humanos, email, SteamID ni datos de dispositivo observados. Logs y archivos de soporte podrían contener datos incidentales.

**Regla de Cartridge & Cloud.** La clasificación depende de identificabilidad y contexto, no del nombre del campo. Un ID persistente, una IP o un patrón conductual pueden ser datos personales.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Nombre visible` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Diccionario de datos, ejemplo de payload y matriz de acceso.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

La clasificación aplica contexto y riesgo de inferencia. No se recopila edad exacta, salud, biometría, chat o categorías especiales para “mejorar segmentación”.

## 29. Email

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **email** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El save contiene estado de juego, IDs sintéticos y timestamps; no contiene nombres humanos, email, SteamID ni datos de dispositivo observados. Logs y archivos de soporte podrían contener datos incidentales.

**Regla de Cartridge & Cloud.** La clasificación depende de identificabilidad y contexto, no del nombre del campo. Un ID persistente, una IP o un patrón conductual pueden ser datos personales.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Email` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Diccionario de datos, ejemplo de payload y matriz de acceso.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

La clasificación aplica contexto y riesgo de inferencia. No se recopila edad exacta, salud, biometría, chat o categorías especiales para “mejorar segmentación”.

## 30. Dirección IP

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **dirección ip** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El save contiene estado de juego, IDs sintéticos y timestamps; no contiene nombres humanos, email, SteamID ni datos de dispositivo observados. Logs y archivos de soporte podrían contener datos incidentales.

**Regla de Cartridge & Cloud.** La clasificación depende de identificabilidad y contexto, no del nombre del campo. Un ID persistente, una IP o un patrón conductual pueden ser datos personales.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Dirección IP` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Diccionario de datos, ejemplo de payload y matriz de acceso.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

La clasificación aplica contexto y riesgo de inferencia. No se recopila edad exacta, salud, biometría, chat o categorías especiales para “mejorar segmentación”.

## 31. Logs

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **logs** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** `Player.log` y logs de build existen localmente. Pueden incluir rutas, nombres de carpetas, stack traces o datos incidentales según entorno. No hay envío automático observado.

**Regla de Cartridge & Cloud.** El soporte solicita el mínimo intervalo, explica cómo revisar/redactar y elimina el archivo tras resolución. Los logs de producto no incluyen texto libre del jugador.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Logs` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Log sanitizado, hash, ticket, acceso y deletion record.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

Los adjuntos voluntarios se consideran potencialmente identificables, se almacenan fuera del repositorio y se vinculan a un ticket mediante un ID interno, no mediante el nombre público del jugador.

## 32. Saves

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **saves** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Los saves viven bajo `Application.persistentDataPath/IntegratedSaveGames` con primary, `.bak`, `.tmp` y `.recovery`, schema 2 (`CurrentSchemaVersion = 2`), IDs sintéticos, timestamps UTC y estado económico/jugable. Permanecen en el equipo salvo envío voluntario o futura Cloud.

**Regla de Cartridge & Cloud.** No se piden saves completos por defecto. Para soporte se recibe una copia, se trabaja en entorno aislado y se elimina según schedule.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Saves` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Save data dictionary, consent/support notice, hash y deletion record.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

Los adjuntos voluntarios se consideran potencialmente identificables, se almacenan fuera del repositorio y se vinculan a un ticket mediante un ID interno, no mediante el nombre público del jugador.

## 33. Crash dumps

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **crash dumps** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe crash SDK externo. Un dump puede contener memoria, rutas, nombres y fragmentos inesperados; es más sensible que un contador de crash.

**Regla de Cartridge & Cloud.** No se habilita captura/subida automática sin proveedor, DPA, política, límites y evaluación. Para soporte manual, se informa antes de solicitarlo.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Crash dumps` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Crash data map, retention, access, vendor contract y redaction procedure.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

Los adjuntos voluntarios se consideran potencialmente identificables, se almacenan fuera del repositorio y se vinculan a un ticket mediante un ID interno, no mediante el nombre público del jugador.

## 34. Capturas

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **capturas** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El save contiene estado de juego, IDs sintéticos y timestamps; no contiene nombres humanos, email, SteamID ni datos de dispositivo observados. Logs y archivos de soporte podrían contener datos incidentales.

**Regla de Cartridge & Cloud.** La clasificación depende de identificabilidad y contexto, no del nombre del campo. Un ID persistente, una IP o un patrón conductual pueden ser datos personales.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Capturas` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Diccionario de datos, ejemplo de payload y matriz de acceso.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

Los adjuntos voluntarios se consideran potencialmente identificables, se almacenan fuera del repositorio y se vinculan a un ticket mediante un ID interno, no mediante el nombre público del jugador.

## 35. Tickets

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **tickets** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El save contiene estado de juego, IDs sintéticos y timestamps; no contiene nombres humanos, email, SteamID ni datos de dispositivo observados. Logs y archivos de soporte podrían contener datos incidentales.

**Regla de Cartridge & Cloud.** La clasificación depende de identificabilidad y contexto, no del nombre del campo. Un ID persistente, una IP o un patrón conductual pueden ser datos personales.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Tickets` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Diccionario de datos, ejemplo de payload y matriz de acceso.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

Los adjuntos voluntarios se consideran potencialmente identificables, se almacenan fuera del repositorio y se vinculan a un ticket mediante un ID interno, no mediante el nombre público del jugador.

## 36. Community Hub

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **community hub** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El save contiene estado de juego, IDs sintéticos y timestamps; no contiene nombres humanos, email, SteamID ni datos de dispositivo observados. Logs y archivos de soporte podrían contener datos incidentales.

**Regla de Cartridge & Cloud.** La clasificación depende de identificabilidad y contexto, no del nombre del campo. Un ID persistente, una IP o un patrón conductual pueden ser datos personales.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Community Hub` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Diccionario de datos, ejemplo de payload y matriz de acceso.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

## 37. Reviews

Este capítulo pertenece al bloque **Clasificación de datos y superficies**. Su objetivo es convertir **reviews** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El save contiene estado de juego, IDs sintéticos y timestamps; no contiene nombres humanos, email, SteamID ni datos de dispositivo observados. Logs y archivos de soporte podrían contener datos incidentales.

**Regla de Cartridge & Cloud.** La clasificación depende de identificabilidad y contexto, no del nombre del campo. Un ID persistente, una IP o un patrón conductual pueden ser datos personales.

**Procedimiento operativo.**
1. Clasificar dato y origen.
2. Identificar quién puede vincularlo.
3. Definir exposición y retención.
4. Marcar si se comparte o permanece local.
5. Registrar específicamente el impacto de `Reviews` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Diccionario de datos, ejemplo de payload y matriz de acceso.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-006; PRIV-OFF-009`.

## 38. Telemetría

Este capítulo pertenece al bloque **Telemetría, métricas y datos comerciales**. Su objetivo es convertir **telemetría** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe integración activa. La AEPD describe la telemetría como monitorización continua que puede individualizar y perfilar; por ello no se trata como simple logging técnico.

**Regla de Cartridge & Cloud.** La primera release deberá funcionar sin telemetría propia. Si se abre, será modular, granular, revisable y desligada del gameplay esencial salvo necesidad demostrada.

**Procedimiento operativo.**
1. Formular pregunta y decisión.
2. Elegir métrica mínima.
3. Definir denominador y ventana.
4. Evaluar privacidad y sesgos.
5. Aprobar o rechazar instrumentación.
6. Registrar específicamente el impacto de `Telemetría` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Feature flag off, event catalog, legal assessment, policy, UI y network test.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-010; PRIV-OFF-011; PRIV-OFF-012`.

La ficha de métrica documenta pregunta, decisión, población, denominador, ventana, timezone, sesgo, coste de privacidad y condición de retirada; sin esa ficha el evento no puede abrirse.

## 39. Analytics

Este capítulo pertenece al bloque **Telemetría, métricas y datos comerciales**. Su objetivo es convertir **analytics** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El módulo built-in `com.unity.modules.unityanalytics` aparece en manifest, pero Unity Analytics está desactivado y no se encontró `Unity.Services.Analytics`. La presencia de un módulo no equivale a recogida activa.

**Regla de Cartridge & Cloud.** No activar Analytics desde Dashboard, package o código sin actualizar arquitectura, RAT, contratos y política.

**Procedimiento operativo.**
1. Formular pregunta y decisión.
2. Elegir métrica mínima.
3. Definir denominador y ventana.
4. Evaluar privacidad y sesgos.
5. Aprobar o rechazar instrumentación.
6. Registrar específicamente el impacto de `Analytics` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Settings export, package lock, dashboard screenshot y traffic capture.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-010; PRIV-OFF-011; PRIV-OFF-012`.

La ficha de métrica documenta pregunta, decisión, población, denominador, ventana, timezone, sesgo, coste de privacidad y condición de retirada; sin esa ficha el evento no puede abrirse.

## 40. Métricas de gameplay

Este capítulo pertenece al bloque **Telemetría, métricas y datos comerciales**. Su objetivo es convertir **métricas de gameplay** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No se encontró telemetría runtime, analytics de UGS, SDK externo, Steamworks ni HTTP de producto. Steamworks futuro puede ofrecer datos agregados de tráfico, ventas y reembolsos.

**Regla de Cartridge & Cloud.** No se recopila un evento porque sea fácil. Cada métrica debe responder a una pregunta y conducir a una decisión autorizada.

**Procedimiento operativo.**
1. Formular pregunta y decisión.
2. Elegir métrica mínima.
3. Definir denominador y ventana.
4. Evaluar privacidad y sesgos.
5. Aprobar o rechazar instrumentación.
6. Registrar específicamente el impacto de `Métricas de gameplay` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Metric card, query reproducible, data owner y decisión asociada.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-010; PRIV-OFF-011; PRIV-OFF-012`.

La ficha de métrica documenta pregunta, decisión, población, denominador, ventana, timezone, sesgo, coste de privacidad y condición de retirada; sin esa ficha el evento no puede abrirse.

## 41. Economía

Este capítulo pertenece al bloque **Telemetría, métricas y datos comerciales**. Su objetivo es convertir **economía** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Las métricas económicas pueden revelar estrategias y patrones si se vinculan a una persona. Para tuning suele bastar distribución agregada de caja, margen, rotación y resultados por día.

**Regla de Cartridge & Cloud.** No enviar ledger completo ni secuencias de compra por usuario. Preferir histogramas/buckets y análisis local en QA.

**Procedimiento operativo.**
1. Formular pregunta y decisión.
2. Elegir métrica mínima.
3. Definir denominador y ventana.
4. Evaluar privacidad y sesgos.
5. Aprobar o rechazar instrumentación.
6. Registrar específicamente el impacto de `Economía` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Metric card, bucket design, aggregation threshold y query.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-010; PRIV-OFF-011; PRIV-OFF-012`.

## 42. Progreso

Este capítulo pertenece al bloque **Telemetría, métricas y datos comerciales**. Su objetivo es convertir **progreso** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No se encontró telemetría runtime, analytics de UGS, SDK externo, Steamworks ni HTTP de producto. Steamworks futuro puede ofrecer datos agregados de tráfico, ventas y reembolsos.

**Regla de Cartridge & Cloud.** No se recopila un evento porque sea fácil. Cada métrica debe responder a una pregunta y conducir a una decisión autorizada.

**Procedimiento operativo.**
1. Formular pregunta y decisión.
2. Elegir métrica mínima.
3. Definir denominador y ventana.
4. Evaluar privacidad y sesgos.
5. Aprobar o rechazar instrumentación.
6. Registrar específicamente el impacto de `Progreso` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Metric card, query reproducible, data owner y decisión asociada.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-010; PRIV-OFF-011; PRIV-OFF-012`.

## 43. Sesiones

Este capítulo pertenece al bloque **Telemetría, métricas y datos comerciales**. Su objetivo es convertir **sesiones** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No se encontró telemetría runtime, analytics de UGS, SDK externo, Steamworks ni HTTP de producto. Steamworks futuro puede ofrecer datos agregados de tráfico, ventas y reembolsos.

**Regla de Cartridge & Cloud.** No se recopila un evento porque sea fácil. Cada métrica debe responder a una pregunta y conducir a una decisión autorizada.

**Procedimiento operativo.**
1. Formular pregunta y decisión.
2. Elegir métrica mínima.
3. Definir denominador y ventana.
4. Evaluar privacidad y sesgos.
5. Aprobar o rechazar instrumentación.
6. Registrar específicamente el impacto de `Sesiones` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Metric card, query reproducible, data owner y decisión asociada.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-010; PRIV-OFF-011; PRIV-OFF-012`.

## 44. Retención de jugadores

Este capítulo pertenece al bloque **Telemetría, métricas y datos comerciales**. Su objetivo es convertir **retención de jugadores** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No se encontró telemetría runtime, analytics de UGS, SDK externo, Steamworks ni HTTP de producto. Steamworks futuro puede ofrecer datos agregados de tráfico, ventas y reembolsos.

**Regla de Cartridge & Cloud.** No se recopila un evento porque sea fácil. Cada métrica debe responder a una pregunta y conducir a una decisión autorizada.

**Procedimiento operativo.**
1. Formular pregunta y decisión.
2. Elegir métrica mínima.
3. Definir denominador y ventana.
4. Evaluar privacidad y sesgos.
5. Aprobar o rechazar instrumentación.
6. Registrar específicamente el impacto de `Retención de jugadores` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Metric card, query reproducible, data owner y decisión asociada.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-010; PRIV-OFF-011; PRIV-OFF-012`.

El borrado cubre índices, objetos primarios y copias operativas; los backups tienen una ventana documentada y no se restauran para reactivar datos que debían eliminarse.

## 45. Abandono

Este capítulo pertenece al bloque **Telemetría, métricas y datos comerciales**. Su objetivo es convertir **abandono** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No se encontró telemetría runtime, analytics de UGS, SDK externo, Steamworks ni HTTP de producto. Steamworks futuro puede ofrecer datos agregados de tráfico, ventas y reembolsos.

**Regla de Cartridge & Cloud.** No se recopila un evento porque sea fácil. Cada métrica debe responder a una pregunta y conducir a una decisión autorizada.

**Procedimiento operativo.**
1. Formular pregunta y decisión.
2. Elegir métrica mínima.
3. Definir denominador y ventana.
4. Evaluar privacidad y sesgos.
5. Aprobar o rechazar instrumentación.
6. Registrar específicamente el impacto de `Abandono` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Metric card, query reproducible, data owner y decisión asociada.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-010; PRIV-OFF-011; PRIV-OFF-012`.

## 46. Rendimiento

Este capítulo pertenece al bloque **Telemetría, métricas y datos comerciales**. Su objetivo es convertir **rendimiento** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No se encontró telemetría runtime, analytics de UGS, SDK externo, Steamworks ni HTTP de producto. Steamworks futuro puede ofrecer datos agregados de tráfico, ventas y reembolsos.

**Regla de Cartridge & Cloud.** No se recopila un evento porque sea fácil. Cada métrica debe responder a una pregunta y conducir a una decisión autorizada.

**Procedimiento operativo.**
1. Formular pregunta y decisión.
2. Elegir métrica mínima.
3. Definir denominador y ventana.
4. Evaluar privacidad y sesgos.
5. Aprobar o rechazar instrumentación.
6. Registrar específicamente el impacto de `Rendimiento` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Metric card, query reproducible, data owner y decisión asociada.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-010; PRIV-OFF-011; PRIV-OFF-012`.

## 47. Errores

Este capítulo pertenece al bloque **Telemetría, métricas y datos comerciales**. Su objetivo es convertir **errores** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No se encontró telemetría runtime, analytics de UGS, SDK externo, Steamworks ni HTTP de producto. Steamworks futuro puede ofrecer datos agregados de tráfico, ventas y reembolsos.

**Regla de Cartridge & Cloud.** No se recopila un evento porque sea fácil. Cada métrica debe responder a una pregunta y conducir a una decisión autorizada.

**Procedimiento operativo.**
1. Formular pregunta y decisión.
2. Elegir métrica mínima.
3. Definir denominador y ventana.
4. Evaluar privacidad y sesgos.
5. Aprobar o rechazar instrumentación.
6. Registrar específicamente el impacto de `Errores` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Metric card, query reproducible, data owner y decisión asociada.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-010; PRIV-OFF-011; PRIV-OFF-012`.

## 48. Softlocks

Este capítulo pertenece al bloque **Telemetría, métricas y datos comerciales**. Su objetivo es convertir **softlocks** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No se encontró telemetría runtime, analytics de UGS, SDK externo, Steamworks ni HTTP de producto. Steamworks futuro puede ofrecer datos agregados de tráfico, ventas y reembolsos.

**Regla de Cartridge & Cloud.** No se recopila un evento porque sea fácil. Cada métrica debe responder a una pregunta y conducir a una decisión autorizada.

**Procedimiento operativo.**
1. Formular pregunta y decisión.
2. Elegir métrica mínima.
3. Definir denominador y ventana.
4. Evaluar privacidad y sesgos.
5. Aprobar o rechazar instrumentación.
6. Registrar específicamente el impacto de `Softlocks` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Metric card, query reproducible, data owner y decisión asociada.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-010; PRIV-OFF-011; PRIV-OFF-012`.

## 49. Stockouts

Este capítulo pertenece al bloque **Telemetría, métricas y datos comerciales**. Su objetivo es convertir **stockouts** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No se encontró telemetría runtime, analytics de UGS, SDK externo, Steamworks ni HTTP de producto. Steamworks futuro puede ofrecer datos agregados de tráfico, ventas y reembolsos.

**Regla de Cartridge & Cloud.** No se recopila un evento porque sea fácil. Cada métrica debe responder a una pregunta y conducir a una decisión autorizada.

**Procedimiento operativo.**
1. Formular pregunta y decisión.
2. Elegir métrica mínima.
3. Definir denominador y ventana.
4. Evaluar privacidad y sesgos.
5. Aprobar o rechazar instrumentación.
6. Registrar específicamente el impacto de `Stockouts` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Metric card, query reproducible, data owner y decisión asociada.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-010; PRIV-OFF-011; PRIV-OFF-012`.

## 50. Conversiones

Este capítulo pertenece al bloque **Telemetría, métricas y datos comerciales**. Su objetivo es convertir **conversiones** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No se encontró telemetría runtime, analytics de UGS, SDK externo, Steamworks ni HTTP de producto. Steamworks futuro puede ofrecer datos agregados de tráfico, ventas y reembolsos.

**Regla de Cartridge & Cloud.** No se recopila un evento porque sea fácil. Cada métrica debe responder a una pregunta y conducir a una decisión autorizada.

**Procedimiento operativo.**
1. Formular pregunta y decisión.
2. Elegir métrica mínima.
3. Definir denominador y ventana.
4. Evaluar privacidad y sesgos.
5. Aprobar o rechazar instrumentación.
6. Registrar específicamente el impacto de `Conversiones` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Metric card, query reproducible, data owner y decisión asociada.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-010; PRIV-OFF-011; PRIV-OFF-012`.

Los informes de Steam se tratan como una fuente separada: el estudio registra qué campos recibe, si son agregados y quién tiene permiso; no infiere acceso a datos individuales por el mero hecho de usar Steamworks.

## 51. Wishlists

Este capítulo pertenece al bloque **Telemetría, métricas y datos comerciales**. Su objetivo es convertir **wishlists** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Steamworks ofrece cifras de plataforma; no requieren que el juego instrumente al jugador. Se consumen como datos comerciales agregados bajo permisos de partner.

**Regla de Cartridge & Cloud.** No intentar reconstruir identidades ni combinar pequeñas cohortes. Acceso restringido a quienes toman decisiones de marketing.

**Procedimiento operativo.**
1. Formular pregunta y decisión.
2. Elegir métrica mínima.
3. Definir denominador y ventana.
4. Evaluar privacidad y sesgos.
5. Aprobar o rechazar instrumentación.
6. Registrar específicamente el impacto de `Wishlists` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Steam report snapshot, permission review y analysis note.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-010; PRIV-OFF-011; PRIV-OFF-012`.

Los informes de Steam se tratan como una fuente separada: el estudio registra qué campos recibe, si son agregados y quién tiene permiso; no infiere acceso a datos individuales por el mero hecho de usar Steamworks.

## 52. Ventas

Este capítulo pertenece al bloque **Telemetría, métricas y datos comerciales**. Su objetivo es convertir **ventas** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No se encontró telemetría runtime, analytics de UGS, SDK externo, Steamworks ni HTTP de producto. Steamworks futuro puede ofrecer datos agregados de tráfico, ventas y reembolsos.

**Regla de Cartridge & Cloud.** No se recopila un evento porque sea fácil. Cada métrica debe responder a una pregunta y conducir a una decisión autorizada.

**Procedimiento operativo.**
1. Formular pregunta y decisión.
2. Elegir métrica mínima.
3. Definir denominador y ventana.
4. Evaluar privacidad y sesgos.
5. Aprobar o rechazar instrumentación.
6. Registrar específicamente el impacto de `Ventas` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Metric card, query reproducible, data owner y decisión asociada.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-010; PRIV-OFF-011; PRIV-OFF-012`.

Los informes de Steam se tratan como una fuente separada: el estudio registra qué campos recibe, si son agregados y quién tiene permiso; no infiere acceso a datos individuales por el mero hecho de usar Steamworks.

## 53. Reembolsos

Este capítulo pertenece al bloque **Telemetría, métricas y datos comerciales**. Su objetivo es convertir **reembolsos** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No se encontró telemetría runtime, analytics de UGS, SDK externo, Steamworks ni HTTP de producto. Steamworks futuro puede ofrecer datos agregados de tráfico, ventas y reembolsos.

**Regla de Cartridge & Cloud.** No se recopila un evento porque sea fácil. Cada métrica debe responder a una pregunta y conducir a una decisión autorizada.

**Procedimiento operativo.**
1. Formular pregunta y decisión.
2. Elegir métrica mínima.
3. Definir denominador y ventana.
4. Evaluar privacidad y sesgos.
5. Aprobar o rechazar instrumentación.
6. Registrar específicamente el impacto de `Reembolsos` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Metric card, query reproducible, data owner y decisión asociada.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-010; PRIV-OFF-011; PRIV-OFF-012`.

Los informes de Steam se tratan como una fuente separada: el estudio registra qué campos recibe, si son agregados y quién tiene permiso; no infiere acceso a datos individuales por el mero hecho de usar Steamworks.

## 54. Datos de Steam

Este capítulo pertenece al bloque **Telemetría, métricas y datos comerciales**. Su objetivo es convertir **datos de steam** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Valve es responsable de sus tratamientos de plataforma y ofrece Privacy Dashboard. El estudio solo debe documentar los datos que recibe o decide tratar, como informes agregados o SteamID si integra APIs.

**Regla de Cartridge & Cloud.** No copiar datos de Steam a sistemas propios sin finalidad y contrato. Separar “Valve procesa” de “VRM Games recibe”.

**Procedimiento operativo.**
1. Formular pregunta y decisión.
2. Elegir métrica mínima.
3. Definir denominador y ventana.
4. Evaluar privacidad y sesgos.
5. Aprobar o rechazar instrumentación.
6. Registrar específicamente el impacto de `Datos de Steam` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Steam data-flow matrix, API inventory and permissions.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-010; PRIV-OFF-011; PRIV-OFF-012`.

Los informes de Steam se tratan como una fuente separada: el estudio registra qué campos recibe, si son agregados y quién tiene permiso; no infiere acceso a datos individuales por el mero hecho de usar Steamworks.

## 55. Datos propios

Este capítulo pertenece al bloque **Telemetría, métricas y datos comerciales**. Su objetivo es convertir **datos propios** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No se encontró telemetría runtime, analytics de UGS, SDK externo, Steamworks ni HTTP de producto. Steamworks futuro puede ofrecer datos agregados de tráfico, ventas y reembolsos.

**Regla de Cartridge & Cloud.** No se recopila un evento porque sea fácil. Cada métrica debe responder a una pregunta y conducir a una decisión autorizada.

**Procedimiento operativo.**
1. Formular pregunta y decisión.
2. Elegir métrica mínima.
3. Definir denominador y ventana.
4. Evaluar privacidad y sesgos.
5. Aprobar o rechazar instrumentación.
6. Registrar específicamente el impacto de `Datos propios` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Metric card, query reproducible, data owner y decisión asociada.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-010; PRIV-OFF-011; PRIV-OFF-012`.

## 56. Datos derivados

Este capítulo pertenece al bloque **Telemetría, métricas y datos comerciales**. Su objetivo es convertir **datos derivados** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No se encontró telemetría runtime, analytics de UGS, SDK externo, Steamworks ni HTTP de producto. Steamworks futuro puede ofrecer datos agregados de tráfico, ventas y reembolsos.

**Regla de Cartridge & Cloud.** No se recopila un evento porque sea fácil. Cada métrica debe responder a una pregunta y conducir a una decisión autorizada.

**Procedimiento operativo.**
1. Formular pregunta y decisión.
2. Elegir métrica mínima.
3. Definir denominador y ventana.
4. Evaluar privacidad y sesgos.
5. Aprobar o rechazar instrumentación.
6. Registrar específicamente el impacto de `Datos derivados` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Metric card, query reproducible, data owner y decisión asociada.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-010; PRIV-OFF-011; PRIV-OFF-012`.

## 57. Datos sensibles

Este capítulo pertenece al bloque **Telemetría, métricas y datos comerciales**. Su objetivo es convertir **datos sensibles** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No se encontró telemetría runtime, analytics de UGS, SDK externo, Steamworks ni HTTP de producto. Steamworks futuro puede ofrecer datos agregados de tráfico, ventas y reembolsos.

**Regla de Cartridge & Cloud.** No se recopila un evento porque sea fácil. Cada métrica debe responder a una pregunta y conducir a una decisión autorizada.

**Procedimiento operativo.**
1. Formular pregunta y decisión.
2. Elegir métrica mínima.
3. Definir denominador y ventana.
4. Evaluar privacidad y sesgos.
5. Aprobar o rechazar instrumentación.
6. Registrar específicamente el impacto de `Datos sensibles` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Metric card, query reproducible, data owner y decisión asociada.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-010; PRIV-OFF-011; PRIV-OFF-012`.

La clasificación aplica contexto y riesgo de inferencia. No se recopila edad exacta, salud, biometría, chat o categorías especiales para “mejorar segmentación”.

## 58. Datos de menores

Este capítulo pertenece al bloque **Telemetría, métricas y datos comerciales**. Su objetivo es convertir **datos de menores** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No se encontró telemetría runtime, analytics de UGS, SDK externo, Steamworks ni HTTP de producto. Steamworks futuro puede ofrecer datos agregados de tráfico, ventas y reembolsos.

**Regla de Cartridge & Cloud.** No se recopila un evento porque sea fácil. Cada métrica debe responder a una pregunta y conducir a una decisión autorizada.

**Procedimiento operativo.**
1. Formular pregunta y decisión.
2. Elegir métrica mínima.
3. Definir denominador y ventana.
4. Evaluar privacidad y sesgos.
5. Aprobar o rechazar instrumentación.
6. Registrar específicamente el impacto de `Datos de menores` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Metric card, query reproducible, data owner y decisión asociada.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-010; PRIV-OFF-011; PRIV-OFF-012`.

La clasificación aplica contexto y riesgo de inferencia. No se recopila edad exacta, salud, biometría, chat o categorías especiales para “mejorar segmentación”.

## 59. Datos prohibidos

Este capítulo pertenece al bloque **Telemetría, métricas y datos comerciales**. Su objetivo es convertir **datos prohibidos** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No se encontró telemetría runtime, analytics de UGS, SDK externo, Steamworks ni HTTP de producto. Steamworks futuro puede ofrecer datos agregados de tráfico, ventas y reembolsos.

**Regla de Cartridge & Cloud.** No se recopila un evento porque sea fácil. Cada métrica debe responder a una pregunta y conducir a una decisión autorizada.

**Procedimiento operativo.**
1. Formular pregunta y decisión.
2. Elegir métrica mínima.
3. Definir denominador y ventana.
4. Evaluar privacidad y sesgos.
5. Aprobar o rechazar instrumentación.
6. Registrar específicamente el impacto de `Datos prohibidos` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Metric card, query reproducible, data owner y decisión asociada.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-010; PRIV-OFF-011; PRIV-OFF-012`.

La clasificación aplica contexto y riesgo de inferencia. No se recopila edad exacta, salud, biometría, chat o categorías especiales para “mejorar segmentación”.

## 60. Fuentes de datos

Este capítulo pertenece al bloque **Fuentes, plataformas y roles**. Su objetivo es convertir **fuentes de datos** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Unity, Steam y futuros proveedores pueden actuar con roles distintos por actividad. El proyecto no dispone hoy de backend, cuenta propia o procesador de telemetría.

**Regla de Cartridge & Cloud.** El rol de responsable, corresponsable o encargado se determina por quién decide fines y medios reales, no por una etiqueta contractual genérica.

**Procedimiento operativo.**
1. Mapear flujo y decisiones.
2. Revisar términos y contrato.
3. Definir reutilización del proveedor.
4. Registrar transferencias y subprocesadores.
5. Registrar específicamente el impacto de `Fuentes de datos` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Matriz de roles, DPA/contrato, lista de subprocesadores y data-flow.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-009; PRIV-OFF-013; PRIV-OFF-014`.

## 61. Unity

Este capítulo pertenece al bloque **Fuentes, plataformas y roles**. Su objetivo es convertir **unity** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El proyecto contiene módulos built-in y `UnityConnectSettings`. Analytics, Cloud Diagnostics, Ads, Purchasing y Performance Reporting están desactivados; Engine Diagnostics aparece habilitado en configuración de herramienta. Esto exige verificación de editor y build por separado.

**Regla de Cartridge & Cloud.** No se asume que un ajuste de editor se incluye en player ni que está exento. Se revisan términos, settings y tráfico de una build limpia.

**Procedimiento operativo.**
1. Mapear flujo y decisiones.
2. Revisar términos y contrato.
3. Definir reutilización del proveedor.
4. Registrar transferencias y subprocesadores.
5. Registrar específicamente el impacto de `Unity` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Unity settings, services dashboard, package manifest y controlled network test.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-009; PRIV-OFF-013; PRIV-OFF-014`.

## 62. Steamworks

Este capítulo pertenece al bloque **Fuentes, plataformas y roles**. Su objetivo es convertir **steamworks** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No está integrado ni existe AppID. Cuando se incorpore, cada API se inventaría por datos, permisos, finalidad y retención.

**Regla de Cartridge & Cloud.** Usar primero reporting agregado de Steam. Autenticación, Web API o backend requieren gate adicional y secretos fuera del cliente.

**Procedimiento operativo.**
1. Mapear flujo y decisiones.
2. Revisar términos y contrato.
3. Definir reutilización del proveedor.
4. Registrar transferencias y subprocesadores.
5. Registrar específicamente el impacto de `Steamworks` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** App/API inventory, permissions, Steamworks users and data-flow.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-009; PRIV-OFF-013; PRIV-OFF-014`.

Los informes de Steam se tratan como una fuente separada: el estudio registra qué campos recibe, si son agregados y quién tiene permiso; no infiere acceso a datos individuales por el mero hecho de usar Steamworks.

## 63. Steam Cloud

Este capítulo pertenece al bloque **Fuentes, plataformas y roles**. Su objetivo es convertir **steam cloud** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No está implementado. Auto-Cloud podría sincronizar `IntegratedSaveGames` sin código, mientras API ofrece control granular. Ambos crean un flujo remoto de archivos por usuario.

**Regla de Cartridge & Cloud.** No activar hasta probar paths, conflictos, backup/recovery, múltiples equipos, opt-out, schema y privacy notice.

**Procedimiento operativo.**
1. Mapear flujo y decisiones.
2. Revisar términos y contrato.
3. Definir reutilización del proveedor.
4. Registrar transferencias y subprocesadores.
5. Registrar específicamente el impacto de `Steam Cloud` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Cloud config, two-device campaign, cloud_log, retention/role assessment.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-009; PRIV-OFF-013; PRIV-OFF-014`.

Los informes de Steam se tratan como una fuente separada: el estudio registra qué campos recibe, si son agregados y quién tiene permiso; no infiere acceso a datos individuales por el mero hecho de usar Steamworks.

## 64. Crash reporting

Este capítulo pertenece al bloque **Fuentes, plataformas y roles**. Su objetivo es convertir **crash reporting** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Unity, Steam y futuros proveedores pueden actuar con roles distintos por actividad. El proyecto no dispone hoy de backend, cuenta propia o procesador de telemetría.

**Regla de Cartridge & Cloud.** El rol de responsable, corresponsable o encargado se determina por quién decide fines y medios reales, no por una etiqueta contractual genérica.

**Procedimiento operativo.**
1. Mapear flujo y decisiones.
2. Revisar términos y contrato.
3. Definir reutilización del proveedor.
4. Registrar transferencias y subprocesadores.
5. Registrar específicamente el impacto de `Crash reporting` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Matriz de roles, DPA/contrato, lista de subprocesadores y data-flow.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-009; PRIV-OFF-013; PRIV-OFF-014`.

Los adjuntos voluntarios se consideran potencialmente identificables, se almacenan fuera del repositorio y se vinculan a un ticket mediante un ID interno, no mediante el nombre público del jugador.

## 65. Sistema de soporte

Este capítulo pertenece al bloque **Fuentes, plataformas y roles**. Su objetivo es convertir **sistema de soporte** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay ticketing ni email público. El soporte futuro puede tratar email, Steam alias, logs, saves, screenshots y hardware aportados voluntariamente.

**Regla de Cartridge & Cloud.** El formulario debe separar campos obligatorios de adjuntos opcionales y mostrar finalidad, retención, contacto y derechos.

**Procedimiento operativo.**
1. Mapear flujo y decisiones.
2. Revisar términos y contrato.
3. Definir reutilización del proveedor.
4. Registrar transferencias y subprocesadores.
5. Registrar específicamente el impacto de `Sistema de soporte` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Support privacy notice, ticket schema, access groups and deletion test.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-009; PRIV-OFF-013; PRIV-OFF-014`.

Los adjuntos voluntarios se consideran potencialmente identificables, se almacenan fuera del repositorio y se vinculan a un ticket mediante un ID interno, no mediante el nombre público del jugador.

## 66. Email de soporte

Este capítulo pertenece al bloque **Fuentes, plataformas y roles**. Su objetivo es convertir **email de soporte** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe dirección pública documentada. Un buzón introduce proveedor, metadatos, spam filtering, backups y accesos.

**Regla de Cartridge & Cloud.** Crear cuenta de dominio con MFA, aliases, acceso mínimo, retención y export/delete. No usar dirección personal del desarrollador.

**Procedimiento operativo.**
1. Mapear flujo y decisiones.
2. Revisar términos y contrato.
3. Definir reutilización del proveedor.
4. Registrar transferencias y subprocesadores.
5. Registrar específicamente el impacto de `Email de soporte` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Provider record, DPA/terms, MFA evidence, retention and test request.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-009; PRIV-OFF-013; PRIV-OFF-014`.

Los adjuntos voluntarios se consideran potencialmente identificables, se almacenan fuera del repositorio y se vinculan a un ticket mediante un ID interno, no mediante el nombre público del jugador. La clasificación aplica contexto y riesgo de inferencia. No se recopila edad exacta, salud, biometría, chat o categorías especiales para “mejorar segmentación”.

## 67. Formularios

Este capítulo pertenece al bloque **Fuentes, plataformas y roles**. Su objetivo es convertir **formularios** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Unity, Steam y futuros proveedores pueden actuar con roles distintos por actividad. El proyecto no dispone hoy de backend, cuenta propia o procesador de telemetría.

**Regla de Cartridge & Cloud.** El rol de responsable, corresponsable o encargado se determina por quién decide fines y medios reales, no por una etiqueta contractual genérica.

**Procedimiento operativo.**
1. Mapear flujo y decisiones.
2. Revisar términos y contrato.
3. Definir reutilización del proveedor.
4. Registrar transferencias y subprocesadores.
5. Registrar específicamente el impacto de `Formularios` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Matriz de roles, DPA/contrato, lista de subprocesadores y data-flow.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-009; PRIV-OFF-013; PRIV-OFF-014`.

## 68. Proveedores externos

Este capítulo pertenece al bloque **Fuentes, plataformas y roles**. Su objetivo es convertir **proveedores externos** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay proveedor de analytics/crash/ticketing seleccionado. OpenAI se ha usado en documentación/concepto, pero no como backend del juego.

**Regla de Cartridge & Cloud.** Cada proveedor se evalúa por datos, rol, localización, subprocesadores, reutilización, seguridad, export/delete y salida.

**Procedimiento operativo.**
1. Mapear flujo y decisiones.
2. Revisar términos y contrato.
3. Definir reutilización del proveedor.
4. Registrar transferencias y subprocesadores.
5. Registrar específicamente el impacto de `Proveedores externos` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Vendor questionnaire, DPA, TOMs, transfer assessment and exit plan.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-009; PRIV-OFF-013; PRIV-OFF-014`.

El proveedor no se aprueba solo por disponer de una política pública: se revisan contrato, DPA, subprocesadores, localización, reutilización, incidentes, exportación, borrado y plan de salida.

## 69. Procesadores

Este capítulo pertenece al bloque **Fuentes, plataformas y roles**. Su objetivo es convertir **procesadores** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Unity, Steam y futuros proveedores pueden actuar con roles distintos por actividad. El proyecto no dispone hoy de backend, cuenta propia o procesador de telemetría.

**Regla de Cartridge & Cloud.** El rol de responsable, corresponsable o encargado se determina por quién decide fines y medios reales, no por una etiqueta contractual genérica.

**Procedimiento operativo.**
1. Mapear flujo y decisiones.
2. Revisar términos y contrato.
3. Definir reutilización del proveedor.
4. Registrar transferencias y subprocesadores.
5. Registrar específicamente el impacto de `Procesadores` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Matriz de roles, DPA/contrato, lista de subprocesadores y data-flow.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-009; PRIV-OFF-013; PRIV-OFF-014`.

El proveedor no se aprueba solo por disponer de una política pública: se revisan contrato, DPA, subprocesadores, localización, reutilización, incidentes, exportación, borrado y plan de salida.

## 70. Subprocesadores

Este capítulo pertenece al bloque **Fuentes, plataformas y roles**. Su objetivo es convertir **subprocesadores** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Unity, Steam y futuros proveedores pueden actuar con roles distintos por actividad. El proyecto no dispone hoy de backend, cuenta propia o procesador de telemetría.

**Regla de Cartridge & Cloud.** El rol de responsable, corresponsable o encargado se determina por quién decide fines y medios reales, no por una etiqueta contractual genérica.

**Procedimiento operativo.**
1. Mapear flujo y decisiones.
2. Revisar términos y contrato.
3. Definir reutilización del proveedor.
4. Registrar transferencias y subprocesadores.
5. Registrar específicamente el impacto de `Subprocesadores` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Matriz de roles, DPA/contrato, lista de subprocesadores y data-flow.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-009; PRIV-OFF-013; PRIV-OFF-014`.

El proveedor no se aprueba solo por disponer de una política pública: se revisan contrato, DPA, subprocesadores, localización, reutilización, incidentes, exportación, borrado y plan de salida.

## 71. Transferencias internacionales

Este capítulo pertenece al bloque **Fuentes, plataformas y roles**. Su objetivo es convertir **transferencias internacionales** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Unity, Steam y futuros proveedores pueden actuar con roles distintos por actividad. El proyecto no dispone hoy de backend, cuenta propia o procesador de telemetría.

**Regla de Cartridge & Cloud.** El rol de responsable, corresponsable o encargado se determina por quién decide fines y medios reales, no por una etiqueta contractual genérica.

**Procedimiento operativo.**
1. Mapear flujo y decisiones.
2. Revisar términos y contrato.
3. Definir reutilización del proveedor.
4. Registrar transferencias y subprocesadores.
5. Registrar específicamente el impacto de `Transferencias internacionales` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Matriz de roles, DPA/contrato, lista de subprocesadores y data-flow.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-009; PRIV-OFF-013; PRIV-OFF-014`.

El proveedor no se aprueba solo por disponer de una política pública: se revisan contrato, DPA, subprocesadores, localización, reutilización, incidentes, exportación, borrado y plan de salida.

## 72. Jurisdicción

Este capítulo pertenece al bloque **Fuentes, plataformas y roles**. Su objetivo es convertir **jurisdicción** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Unity, Steam y futuros proveedores pueden actuar con roles distintos por actividad. El proyecto no dispone hoy de backend, cuenta propia o procesador de telemetría.

**Regla de Cartridge & Cloud.** El rol de responsable, corresponsable o encargado se determina por quién decide fines y medios reales, no por una etiqueta contractual genérica.

**Procedimiento operativo.**
1. Mapear flujo y decisiones.
2. Revisar términos y contrato.
3. Definir reutilización del proveedor.
4. Registrar transferencias y subprocesadores.
5. Registrar específicamente el impacto de `Jurisdicción` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Matriz de roles, DPA/contrato, lista de subprocesadores y data-flow.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-009; PRIV-OFF-013; PRIV-OFF-014`.

El proveedor no se aprueba solo por disponer de una política pública: se revisan contrato, DPA, subprocesadores, localización, reutilización, incidentes, exportación, borrado y plan de salida.

## 73. Responsable del tratamiento

Este capítulo pertenece al bloque **Fuentes, plataformas y roles**. Su objetivo es convertir **responsable del tratamiento** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Unity, Steam y futuros proveedores pueden actuar con roles distintos por actividad. El proyecto no dispone hoy de backend, cuenta propia o procesador de telemetría.

**Regla de Cartridge & Cloud.** El rol de responsable, corresponsable o encargado se determina por quién decide fines y medios reales, no por una etiqueta contractual genérica.

**Procedimiento operativo.**
1. Mapear flujo y decisiones.
2. Revisar términos y contrato.
3. Definir reutilización del proveedor.
4. Registrar transferencias y subprocesadores.
5. Registrar específicamente el impacto de `Responsable del tratamiento` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Matriz de roles, DPA/contrato, lista de subprocesadores y data-flow.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-009; PRIV-OFF-013; PRIV-OFF-014`.

## 74. Encargado del tratamiento

Este capítulo pertenece al bloque **Fuentes, plataformas y roles**. Su objetivo es convertir **encargado del tratamiento** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Unity, Steam y futuros proveedores pueden actuar con roles distintos por actividad. El proyecto no dispone hoy de backend, cuenta propia o procesador de telemetría.

**Regla de Cartridge & Cloud.** El rol de responsable, corresponsable o encargado se determina por quién decide fines y medios reales, no por una etiqueta contractual genérica.

**Procedimiento operativo.**
1. Mapear flujo y decisiones.
2. Revisar términos y contrato.
3. Definir reutilización del proveedor.
4. Registrar transferencias y subprocesadores.
5. Registrar específicamente el impacto de `Encargado del tratamiento` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Matriz de roles, DPA/contrato, lista de subprocesadores y data-flow.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-009; PRIV-OFF-013; PRIV-OFF-014`.

## 75. Base jurídica

Este capítulo pertenece al bloque **Bases jurídicas y control del jugador**. Su objetivo es convertir **base jurídica** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe hoy tratamiento propio remoto que requiera una pantalla de consentimiento. Activar telemetría, newsletter o cuenta cambiaría ese estado.

**Regla de Cartridge & Cloud.** La base jurídica se define por finalidad antes de recoger. El consentimiento, cuando se use, debe ser libre, específico, informado, inequívoco, granular y revocable.

**Procedimiento operativo.**
1. Describir finalidad y necesidad.
2. Seleccionar y justificar base.
3. Diseñar alternativa cuando proceda.
4. Registrar elección y revocación.
5. Registrar específicamente el impacto de `Base jurídica` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Legal-basis assessment, copy, UI, consentimiento versionado y prueba de retirada.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-002; PRIV-OFF-004`.

## 76. Contrato

Este capítulo pertenece al bloque **Bases jurídicas y control del jugador**. Su objetivo es convertir **contrato** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe hoy tratamiento propio remoto que requiera una pantalla de consentimiento. Activar telemetría, newsletter o cuenta cambiaría ese estado.

**Regla de Cartridge & Cloud.** La base jurídica se define por finalidad antes de recoger. El consentimiento, cuando se use, debe ser libre, específico, informado, inequívoco, granular y revocable.

**Procedimiento operativo.**
1. Describir finalidad y necesidad.
2. Seleccionar y justificar base.
3. Diseñar alternativa cuando proceda.
4. Registrar elección y revocación.
5. Registrar específicamente el impacto de `Contrato` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Legal-basis assessment, copy, UI, consentimiento versionado y prueba de retirada.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-002; PRIV-OFF-004`.

El proveedor no se aprueba solo por disponer de una política pública: se revisan contrato, DPA, subprocesadores, localización, reutilización, incidentes, exportación, borrado y plan de salida.

## 77. Interés legítimo

Este capítulo pertenece al bloque **Bases jurídicas y control del jugador**. Su objetivo es convertir **interés legítimo** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe hoy tratamiento propio remoto que requiera una pantalla de consentimiento. Activar telemetría, newsletter o cuenta cambiaría ese estado.

**Regla de Cartridge & Cloud.** La base jurídica se define por finalidad antes de recoger. El consentimiento, cuando se use, debe ser libre, específico, informado, inequívoco, granular y revocable.

**Procedimiento operativo.**
1. Describir finalidad y necesidad.
2. Seleccionar y justificar base.
3. Diseñar alternativa cuando proceda.
4. Registrar elección y revocación.
5. Registrar específicamente el impacto de `Interés legítimo` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Legal-basis assessment, copy, UI, consentimiento versionado y prueba de retirada.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-002; PRIV-OFF-004`.

## 78. Consentimiento

Este capítulo pertenece al bloque **Bases jurídicas y control del jugador**. Su objetivo es convertir **consentimiento** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay UI de consentimiento. No debe añadirse un banner genérico si no existe tratamiento opcional. Si se usa consentimiento, la experiencia no empleará dark patterns ni aceptación agrupada.

**Regla de Cartridge & Cloud.** Consentimiento separado por finalidad, rechazo equivalente, registro versionado y retirada desde opciones.

**Procedimiento operativo.**
1. Describir finalidad y necesidad.
2. Seleccionar y justificar base.
3. Diseñar alternativa cuando proceda.
4. Registrar elección y revocación.
5. Registrar específicamente el impacto de `Consentimiento` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Consent receipt, UI screenshots, revoke test and behavior verification.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-002; PRIV-OFF-004`.

La QA verifica simetría entre aceptar y rechazar, ausencia de transmisión previa, persistencia de la elección y efecto real de la revocación, no solo el cambio visual del toggle.

## 79. Obligación legal

Este capítulo pertenece al bloque **Bases jurídicas y control del jugador**. Su objetivo es convertir **obligación legal** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe hoy tratamiento propio remoto que requiera una pantalla de consentimiento. Activar telemetría, newsletter o cuenta cambiaría ese estado.

**Regla de Cartridge & Cloud.** La base jurídica se define por finalidad antes de recoger. El consentimiento, cuando se use, debe ser libre, específico, informado, inequívoco, granular y revocable.

**Procedimiento operativo.**
1. Describir finalidad y necesidad.
2. Seleccionar y justificar base.
3. Diseñar alternativa cuando proceda.
4. Registrar elección y revocación.
5. Registrar específicamente el impacto de `Obligación legal` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Legal-basis assessment, copy, UI, consentimiento versionado y prueba de retirada.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-002; PRIV-OFF-004`.

## 80. Ejecución del servicio

Este capítulo pertenece al bloque **Bases jurídicas y control del jugador**. Su objetivo es convertir **ejecución del servicio** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe hoy tratamiento propio remoto que requiera una pantalla de consentimiento. Activar telemetría, newsletter o cuenta cambiaría ese estado.

**Regla de Cartridge & Cloud.** La base jurídica se define por finalidad antes de recoger. El consentimiento, cuando se use, debe ser libre, específico, informado, inequívoco, granular y revocable.

**Procedimiento operativo.**
1. Describir finalidad y necesidad.
2. Seleccionar y justificar base.
3. Diseñar alternativa cuando proceda.
4. Registrar elección y revocación.
5. Registrar específicamente el impacto de `Ejecución del servicio` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Legal-basis assessment, copy, UI, consentimiento versionado y prueba de retirada.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-002; PRIV-OFF-004`.

## 81. Consentimiento opcional

Este capítulo pertenece al bloque **Bases jurídicas y control del jugador**. Su objetivo es convertir **consentimiento opcional** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe hoy tratamiento propio remoto que requiera una pantalla de consentimiento. Activar telemetría, newsletter o cuenta cambiaría ese estado.

**Regla de Cartridge & Cloud.** La base jurídica se define por finalidad antes de recoger. El consentimiento, cuando se use, debe ser libre, específico, informado, inequívoco, granular y revocable.

**Procedimiento operativo.**
1. Describir finalidad y necesidad.
2. Seleccionar y justificar base.
3. Diseñar alternativa cuando proceda.
4. Registrar elección y revocación.
5. Registrar específicamente el impacto de `Consentimiento opcional` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Legal-basis assessment, copy, UI, consentimiento versionado y prueba de retirada.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-002; PRIV-OFF-004`.

La QA verifica simetría entre aceptar y rechazar, ausencia de transmisión previa, persistencia de la elección y efecto real de la revocación, no solo el cambio visual del toggle.

## 82. Revocación

Este capítulo pertenece al bloque **Bases jurídicas y control del jugador**. Su objetivo es convertir **revocación** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe hoy tratamiento propio remoto que requiera una pantalla de consentimiento. Activar telemetría, newsletter o cuenta cambiaría ese estado.

**Regla de Cartridge & Cloud.** La base jurídica se define por finalidad antes de recoger. El consentimiento, cuando se use, debe ser libre, específico, informado, inequívoco, granular y revocable.

**Procedimiento operativo.**
1. Describir finalidad y necesidad.
2. Seleccionar y justificar base.
3. Diseñar alternativa cuando proceda.
4. Registrar elección y revocación.
5. Registrar específicamente el impacto de `Revocación` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Legal-basis assessment, copy, UI, consentimiento versionado y prueba de retirada.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-002; PRIV-OFF-004`.

La QA verifica simetría entre aceptar y rechazar, ausencia de transmisión previa, persistencia de la elección y efecto real de la revocación, no solo el cambio visual del toggle.

## 83. Telemetría opt-in

Este capítulo pertenece al bloque **Bases jurídicas y control del jugador**. Su objetivo es convertir **telemetría opt-in** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** La política objetivo es opt-in para telemetría opcional de gameplay si llega a implementarse, salvo que revisión legal documentada concluya otra base y diseño proporcional.

**Regla de Cartridge & Cloud.** El juego funciona plenamente sin aceptar. La opción se presenta después de información clara y puede modificarse.

**Procedimiento operativo.**
1. Describir finalidad y necesidad.
2. Seleccionar y justificar base.
3. Diseñar alternativa cuando proceda.
4. Registrar elección y revocación.
5. Registrar específicamente el impacto de `Telemetría opt-in` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** A/B-free consent UI, default off, network capture before/after and receipt.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-002; PRIV-OFF-004`.

La ficha de métrica documenta pregunta, decisión, población, denominador, ventana, timezone, sesgo, coste de privacidad y condición de retirada; sin esa ficha el evento no puede abrirse. La QA verifica simetría entre aceptar y rechazar, ausencia de transmisión previa, persistencia de la elección y efecto real de la revocación, no solo el cambio visual del toggle.

## 84. Telemetría opt-out

Este capítulo pertenece al bloque **Bases jurídicas y control del jugador**. Su objetivo es convertir **telemetría opt-out** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe hoy tratamiento propio remoto que requiera una pantalla de consentimiento. Activar telemetría, newsletter o cuenta cambiaría ese estado.

**Regla de Cartridge & Cloud.** La base jurídica se define por finalidad antes de recoger. El consentimiento, cuando se use, debe ser libre, específico, informado, inequívoco, granular y revocable.

**Procedimiento operativo.**
1. Describir finalidad y necesidad.
2. Seleccionar y justificar base.
3. Diseñar alternativa cuando proceda.
4. Registrar elección y revocación.
5. Registrar específicamente el impacto de `Telemetría opt-out` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Legal-basis assessment, copy, UI, consentimiento versionado y prueba de retirada.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-002; PRIV-OFF-004`.

La ficha de métrica documenta pregunta, decisión, población, denominador, ventana, timezone, sesgo, coste de privacidad y condición de retirada; sin esa ficha el evento no puede abrirse. La QA verifica simetría entre aceptar y rechazar, ausencia de transmisión previa, persistencia de la elección y efecto real de la revocación, no solo el cambio visual del toggle.

## 85. Configuración por defecto

Este capítulo pertenece al bloque **Bases jurídicas y control del jugador**. Su objetivo es convertir **configuración por defecto** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El default actual efectivo es ausencia de telemetría propia. Debe conservarse hasta un gate formal.

**Regla de Cartridge & Cloud.** Privacy by default: funciones opcionales desactivadas, granularidad mínima y no transmisión antes de decisión.

**Procedimiento operativo.**
1. Describir finalidad y necesidad.
2. Seleccionar y justificar base.
3. Diseñar alternativa cuando proceda.
4. Registrar elección y revocación.
5. Registrar específicamente el impacto de `Configuración por defecto` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Fresh-install test, config snapshot and packet capture.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-002; PRIV-OFF-004`.

La QA verifica simetría entre aceptar y rechazar, ausencia de transmisión previa, persistencia de la elección y efecto real de la revocación, no solo el cambio visual del toggle.

## 86. Datos imprescindibles

Este capítulo pertenece al bloque **Bases jurídicas y control del jugador**. Su objetivo es convertir **datos imprescindibles** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe hoy tratamiento propio remoto que requiera una pantalla de consentimiento. Activar telemetría, newsletter o cuenta cambiaría ese estado.

**Regla de Cartridge & Cloud.** La base jurídica se define por finalidad antes de recoger. El consentimiento, cuando se use, debe ser libre, específico, informado, inequívoco, granular y revocable.

**Procedimiento operativo.**
1. Describir finalidad y necesidad.
2. Seleccionar y justificar base.
3. Diseñar alternativa cuando proceda.
4. Registrar elección y revocación.
5. Registrar específicamente el impacto de `Datos imprescindibles` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Legal-basis assessment, copy, UI, consentimiento versionado y prueba de retirada.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-002; PRIV-OFF-004`.

## 87. Datos opcionales

Este capítulo pertenece al bloque **Bases jurídicas y control del jugador**. Su objetivo es convertir **datos opcionales** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe hoy tratamiento propio remoto que requiera una pantalla de consentimiento. Activar telemetría, newsletter o cuenta cambiaría ese estado.

**Regla de Cartridge & Cloud.** La base jurídica se define por finalidad antes de recoger. El consentimiento, cuando se use, debe ser libre, específico, informado, inequívoco, granular y revocable.

**Procedimiento operativo.**
1. Describir finalidad y necesidad.
2. Seleccionar y justificar base.
3. Diseñar alternativa cuando proceda.
4. Registrar elección y revocación.
5. Registrar específicamente el impacto de `Datos opcionales` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Legal-basis assessment, copy, UI, consentimiento versionado y prueba de retirada.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-002; PRIV-OFF-004`.

## 88. Eventos de telemetría

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **eventos de telemetría** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** El catálogo futuro se limita a eventos definidos, por ejemplo resultado de load/save, cierre de día o bucket de rendimiento; no contiene narrativa, texto libre ni IDs de mundo innecesarios.

**Regla de Cartridge & Cloud.** Todo evento tiene owner, pregunta, propiedades permitidas, retention, schema, sampling y fecha de retirada.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Eventos de telemetría` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Event catalog and generated validator tests.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

La ficha de métrica documenta pregunta, decisión, población, denominador, ventana, timezone, sesgo, coste de privacidad y condición de retirada; sin esa ficha el evento no puede abrirse.

| Event ID propuesto | Finalidad | Propiedades permitidas | Estado |
|---|---|---|---|
| `app_session_started` | estabilidad de versión | app_version, build, locale | NOT OPEN |
| `save_operation_result` | detectar fallos de save | operation, result, schema | NOT OPEN |
| `day_closed` | validar loop | day_bucket, cash_bucket | NOT OPEN |
| `checkout_completed` | balance agregado | basket_size_bucket, revenue_bucket | NOT OPEN |
| `stockout_observed` | contenido/balance | category, duration_bucket | NOT OPEN |
| `performance_sample` | rendimiento | fps_bucket, scene, quality_tier | NOT OPEN |
| `ui_error_shown` | calidad UI | error_code, screen | NOT OPEN |

## 89. Convenciones de eventos

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **convenciones de eventos** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay catálogo de eventos activo. El plan propone una convención futura y deshabilitada por defecto, sin texto libre ni IDs de plataforma.

**Regla de Cartridge & Cloud.** El esquema debe impedir datos excesivos por construcción, usar allowlists, límites, validación, separación de entornos y minimización de linkability.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Convenciones de eventos` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Event catalog, JSON schema, tests negativos y muestra de payload sanitizado.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

La ficha de métrica documenta pregunta, decisión, población, denominador, ventana, timezone, sesgo, coste de privacidad y condición de retirada; sin esa ficha el evento no puede abrirse.

```text
event_id: snake_case, estable y semántico
schema_version: entero positivo
occurred_at: UTC, precisión mínima necesaria
properties: allowlist tipada
user_id: prohibido por defecto
free_text: prohibido
unknown_properties: reject
```

## 90. Propiedades

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **propiedades** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay catálogo de eventos activo. El plan propone una convención futura y deshabilitada por defecto, sin texto libre ni IDs de plataforma.

**Regla de Cartridge & Cloud.** El esquema debe impedir datos excesivos por construcción, usar allowlists, límites, validación, separación de entornos y minimización de linkability.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Propiedades` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Event catalog, JSON schema, tests negativos y muestra de payload sanitizado.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

## 91. IDs de evento

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **ids de evento** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay catálogo de eventos activo. El plan propone una convención futura y deshabilitada por defecto, sin texto libre ni IDs de plataforma.

**Regla de Cartridge & Cloud.** El esquema debe impedir datos excesivos por construcción, usar allowlists, límites, validación, separación de entornos y minimización de linkability.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `IDs de evento` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Event catalog, JSON schema, tests negativos y muestra de payload sanitizado.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

La ficha de métrica documenta pregunta, decisión, población, denominador, ventana, timezone, sesgo, coste de privacidad y condición de retirada; sin esa ficha el evento no puede abrirse.

## 92. Versionado del esquema

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **versionado del esquema** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay catálogo de eventos activo. El plan propone una convención futura y deshabilitada por defecto, sin texto libre ni IDs de plataforma.

**Regla de Cartridge & Cloud.** El esquema debe impedir datos excesivos por construcción, usar allowlists, límites, validación, separación de entornos y minimización de linkability.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Versionado del esquema` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Event catalog, JSON schema, tests negativos y muestra de payload sanitizado.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

## 93. Eventos obsoletos

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **eventos obsoletos** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay catálogo de eventos activo. El plan propone una convención futura y deshabilitada por defecto, sin texto libre ni IDs de plataforma.

**Regla de Cartridge & Cloud.** El esquema debe impedir datos excesivos por construcción, usar allowlists, límites, validación, separación de entornos y minimización de linkability.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Eventos obsoletos` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Event catalog, JSON schema, tests negativos y muestra de payload sanitizado.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

La ficha de métrica documenta pregunta, decisión, población, denominador, ventana, timezone, sesgo, coste de privacidad y condición de retirada; sin esa ficha el evento no puede abrirse.

## 94. Validación

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **validación** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay catálogo de eventos activo. El plan propone una convención futura y deshabilitada por defecto, sin texto libre ni IDs de plataforma.

**Regla de Cartridge & Cloud.** El esquema debe impedir datos excesivos por construcción, usar allowlists, límites, validación, separación de entornos y minimización de linkability.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Validación` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Event catalog, JSON schema, tests negativos y muestra de payload sanitizado.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

## 95. Sampling

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **sampling** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay catálogo de eventos activo. El plan propone una convención futura y deshabilitada por defecto, sin texto libre ni IDs de plataforma.

**Regla de Cartridge & Cloud.** El esquema debe impedir datos excesivos por construcción, usar allowlists, límites, validación, separación de entornos y minimización de linkability.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Sampling` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Event catalog, JSON schema, tests negativos y muestra de payload sanitizado.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

La ficha de métrica documenta pregunta, decisión, población, denominador, ventana, timezone, sesgo, coste de privacidad y condición de retirada; sin esa ficha el evento no puede abrirse.

## 96. Frecuencia

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **frecuencia** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay catálogo de eventos activo. El plan propone una convención futura y deshabilitada por defecto, sin texto libre ni IDs de plataforma.

**Regla de Cartridge & Cloud.** El esquema debe impedir datos excesivos por construcción, usar allowlists, límites, validación, separación de entornos y minimización de linkability.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Frecuencia` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Event catalog, JSON schema, tests negativos y muestra de payload sanitizado.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

La ficha de métrica documenta pregunta, decisión, población, denominador, ventana, timezone, sesgo, coste de privacidad y condición de retirada; sin esa ficha el evento no puede abrirse.

## 97. Batching

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **batching** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay catálogo de eventos activo. El plan propone una convención futura y deshabilitada por defecto, sin texto libre ni IDs de plataforma.

**Regla de Cartridge & Cloud.** El esquema debe impedir datos excesivos por construcción, usar allowlists, límites, validación, separación de entornos y minimización de linkability.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Batching` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Event catalog, JSON schema, tests negativos y muestra de payload sanitizado.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

La ficha de métrica documenta pregunta, decisión, población, denominador, ventana, timezone, sesgo, coste de privacidad y condición de retirada; sin esa ficha el evento no puede abrirse.

## 98. Envío offline

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **envío offline** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay catálogo de eventos activo. El plan propone una convención futura y deshabilitada por defecto, sin texto libre ni IDs de plataforma.

**Regla de Cartridge & Cloud.** El esquema debe impedir datos excesivos por construcción, usar allowlists, límites, validación, separación de entornos y minimización de linkability.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Envío offline` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Event catalog, JSON schema, tests negativos y muestra de payload sanitizado.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

## 99. Reintentos

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **reintentos** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay catálogo de eventos activo. El plan propone una convención futura y deshabilitada por defecto, sin texto libre ni IDs de plataforma.

**Regla de Cartridge & Cloud.** El esquema debe impedir datos excesivos por construcción, usar allowlists, límites, validación, separación de entornos y minimización de linkability.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Reintentos` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Event catalog, JSON schema, tests negativos y muestra de payload sanitizado.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

## 100. Límites

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **límites** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay catálogo de eventos activo. El plan propone una convención futura y deshabilitada por defecto, sin texto libre ni IDs de plataforma.

**Regla de Cartridge & Cloud.** El esquema debe impedir datos excesivos por construcción, usar allowlists, límites, validación, separación de entornos y minimización de linkability.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Límites` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Event catalog, JSON schema, tests negativos y muestra de payload sanitizado.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

## 101. Evitar texto libre

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **evitar texto libre** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay catálogo de eventos activo. El plan propone una convención futura y deshabilitada por defecto, sin texto libre ni IDs de plataforma.

**Regla de Cartridge & Cloud.** El esquema debe impedir datos excesivos por construcción, usar allowlists, límites, validación, separación de entornos y minimización de linkability.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Evitar texto libre` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Event catalog, JSON schema, tests negativos y muestra de payload sanitizado.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

## 102. Evitar saves completos

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **evitar saves completos** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Un save contiene una trayectoria detallada y puede convertirse en perfil conductual si se sube. No debe utilizarse como payload de analytics.

**Regla de Cartridge & Cloud.** Para diagnóstico se extrae localmente un resumen mínimo o se solicita voluntariamente en un ticket concreto.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Evitar saves completos` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Extraction tool, consent text, sample minimized payload.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

Los adjuntos voluntarios se consideran potencialmente identificables, se almacenan fuera del repositorio y se vinculan a un ticket mediante un ID interno, no mediante el nombre público del jugador.

## 103. Evitar rutas de usuario

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **evitar rutas de usuario** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Rutas como `C:\Users\Nombre` pueden identificar al usuario y revelar estructura local. Stack traces y excepciones pueden incluirlas.

**Regla de Cartridge & Cloud.** Redactar segmentos de home/user antes de enviar o persistir. Usar tokens como `<USER_HOME>`.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Evitar rutas de usuario` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Unit tests with Windows/Linux path fixtures and sanitized output.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

## 104. Evitar nombres de PC

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **evitar nombres de pc** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay catálogo de eventos activo. El plan propone una convención futura y deshabilitada por defecto, sin texto libre ni IDs de plataforma.

**Regla de Cartridge & Cloud.** El esquema debe impedir datos excesivos por construcción, usar allowlists, límites, validación, separación de entornos y minimización de linkability.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Evitar nombres de PC` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Event catalog, JSON schema, tests negativos y muestra de payload sanitizado.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

## 105. Evitar tokens

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **evitar tokens** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Nunca registrar Steam Web API keys, OAuth/session tickets, email tokens, cookies o secretos de proveedor.

**Regla de Cartridge & Cloud.** Secret scanning, allowlist de campos, logs estructurados y redaction antes de storage.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Evitar tokens` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Secret-scan report and negative tests.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

## 106. Redacción de logs

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **redacción de logs** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** La redacción ocurre antes de transmisión y, cuando sea posible, antes de escritura. No depende solo de un agente de soporte humano.

**Regla de Cartridge & Cloud.** Patrones para rutas, emails, IP, SteamID, tokens y query strings; fallar cerrado para campos desconocidos.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Redacción de logs` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Redaction library tests and corpus.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

Los adjuntos voluntarios se consideran potencialmente identificables, se almacenan fuera del repositorio y se vinculan a un ticket mediante un ID interno, no mediante el nombre público del jugador.

```text
C:\Users\Alice\AppData\...  -> <USER_HOME>\AppData\...
alice@example.com              -> <EMAIL>
7656119xxxxxxxxxx              -> <STEAM_ID>
Authorization: Bearer ...     -> Authorization: <REDACTED>
203.0.113.42                  -> <IP>
```

## 107. Sanitización

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **sanitización** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay catálogo de eventos activo. El plan propone una convención futura y deshabilitada por defecto, sin texto libre ni IDs de plataforma.

**Regla de Cartridge & Cloud.** El esquema debe impedir datos excesivos por construcción, usar allowlists, límites, validación, separación de entornos y minimización de linkability.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Sanitización` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Event catalog, JSON schema, tests negativos y muestra de payload sanitizado.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

## 108. Hashing

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **hashing** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Hashing no anonimiza automáticamente. IDs de dominio pequeño, SteamID o email pueden ser atacados o correlacionados.

**Regla de Cartridge & Cloud.** Usar hashing solo con finalidad técnica concreta, salt/pepper protegido y evaluación de linkability.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Hashing` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Threat model, algorithm/version and key management.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

## 109. Salt

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **salt** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay catálogo de eventos activo. El plan propone una convención futura y deshabilitada por defecto, sin texto libre ni IDs de plataforma.

**Regla de Cartridge & Cloud.** El esquema debe impedir datos excesivos por construcción, usar allowlists, límites, validación, separación de entornos y minimización de linkability.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Salt` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Event catalog, JSON schema, tests negativos y muestra de payload sanitizado.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

## 110. Identificadores rotatorios

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **identificadores rotatorios** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay catálogo de eventos activo. El plan propone una convención futura y deshabilitada por defecto, sin texto libre ni IDs de plataforma.

**Regla de Cartridge & Cloud.** El esquema debe impedir datos excesivos por construcción, usar allowlists, límites, validación, separación de entornos y minimización de linkability.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Identificadores rotatorios` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Event catalog, JSON schema, tests negativos y muestra de payload sanitizado.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

## 111. Agregación

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **agregación** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay catálogo de eventos activo. El plan propone una convención futura y deshabilitada por defecto, sin texto libre ni IDs de plataforma.

**Regla de Cartridge & Cloud.** El esquema debe impedir datos excesivos por construcción, usar allowlists, límites, validación, separación de entornos y minimización de linkability.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Agregación` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Event catalog, JSON schema, tests negativos y muestra de payload sanitizado.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

La ficha de métrica documenta pregunta, decisión, población, denominador, ventana, timezone, sesgo, coste de privacidad y condición de retirada; sin esa ficha el evento no puede abrirse.

## 112. K-anonymity o umbrales

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **k-anonymity o umbrales** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Steam aplica umbrales en UTM reporting. Para informes propios futuros, grupos pequeños deben suprimirse o agruparse.

**Regla de Cartridge & Cloud.** K-anonymity es una medida auxiliar, no garantía completa; revisar atributos cuasi-identificadores y ataques por composición.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `K-anonymity o umbrales` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Threshold policy, query tests and suppressed-cell audit.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

## 113. Retención por categoría

Este capítulo pertenece al bloque **Diseño de eventos y privacy engineering**. Su objetivo es convertir **retención por categoría** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe retención remota. Este plan propone máximos iniciales para soporte y futuros datos, sujetos a validación legal y operacional.

**Regla de Cartridge & Cloud.** Cada categoría tiene purpose, trigger de inicio, plazo, borrado, backup lag y excepción documentada.

**Procedimiento operativo.**
1. Definir schema y allowlist.
2. Validar cliente y servidor/endpoint.
3. Aplicar límites y redacción.
4. Versionar y retirar eventos.
5. Probar ausencia de datos prohibidos.
6. Registrar específicamente el impacto de `Retención por categoría` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Retention table and automated deletion evidence.

**Referencias oficiales relacionadas:** `PRIV-OFF-004; PRIV-OFF-006`.

El borrado cubre índices, objetos primarios y copias operativas; los backups tienen una ventana documentada y no se restauran para reactivar datos que debían eliminarse.

| Categoría futura | Plazo inicial propuesto | Trigger | Observación |
|---|---:|---|---|
| ticket y email | 24 meses tras cierre | cierre del caso | revisar anual y obligaciones |
| log/save adjunto | 90 días tras cierre | resolución | ampliar solo con motivo documentado |
| crash raw/dump | 90 días | ingestión | acceso muy restringido |
| eventos raw opcionales | 90 días | evento | si se abre; preferir menos |
| agregados seudónimos | 13 meses | periodo de reporte | evaluar linkability |
| agregados anonimizados | según necesidad histórica | anonimización verificada | revisión periódica |
| consent receipts | mientras se trate + defensa aplicable | revocación/fin | revisión legal |
| security access logs | 12 meses | registro | ajustar a riesgo |

## 114. Eliminación

Este capítulo pertenece al bloque **Retención, eliminación y derechos**. Su objetivo es convertir **eliminación** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe repositorio remoto propio. Los archivos locales son controlados por el jugador; los recibidos para soporte requerirán retención y borrado.

**Regla de Cartridge & Cloud.** Conservar solo mientras sea necesario. La seudonimización no justifica retención indefinida. Los derechos deben ser ejercitables y verificables.

**Procedimiento operativo.**
1. Asignar plazo y trigger de borrado.
2. Separar backup y producción.
3. Implementar búsqueda/export/delete.
4. Registrar solicitud y respuesta.
5. Registrar específicamente el impacto de `Eliminación` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Retention schedule, deletion log, export sample y rights request record.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-006; PRIV-OFF-009; PRIV-OFF-015`.

El borrado cubre índices, objetos primarios y copias operativas; los backups tienen una ventana documentada y no se restauran para reactivar datos que debían eliminarse.

## 115. Backups

Este capítulo pertenece al bloque **Retención, eliminación y derechos**. Su objetivo es convertir **backups** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe repositorio remoto propio. Los archivos locales son controlados por el jugador; los recibidos para soporte requerirán retención y borrado.

**Regla de Cartridge & Cloud.** Conservar solo mientras sea necesario. La seudonimización no justifica retención indefinida. Los derechos deben ser ejercitables y verificables.

**Procedimiento operativo.**
1. Asignar plazo y trigger de borrado.
2. Separar backup y producción.
3. Implementar búsqueda/export/delete.
4. Registrar solicitud y respuesta.
5. Registrar específicamente el impacto de `Backups` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Retention schedule, deletion log, export sample y rights request record.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-006; PRIV-OFF-009; PRIV-OFF-015`.

El borrado cubre índices, objetos primarios y copias operativas; los backups tienen una ventana documentada y no se restauran para reactivar datos que debían eliminarse.

## 116. Restauración

Este capítulo pertenece al bloque **Retención, eliminación y derechos**. Su objetivo es convertir **restauración** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe repositorio remoto propio. Los archivos locales son controlados por el jugador; los recibidos para soporte requerirán retención y borrado.

**Regla de Cartridge & Cloud.** Conservar solo mientras sea necesario. La seudonimización no justifica retención indefinida. Los derechos deben ser ejercitables y verificables.

**Procedimiento operativo.**
1. Asignar plazo y trigger de borrado.
2. Separar backup y producción.
3. Implementar búsqueda/export/delete.
4. Registrar solicitud y respuesta.
5. Registrar específicamente el impacto de `Restauración` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Retention schedule, deletion log, export sample y rights request record.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-006; PRIV-OFF-009; PRIV-OFF-015`.

## 117. Legal hold

Este capítulo pertenece al bloque **Retención, eliminación y derechos**. Su objetivo es convertir **legal hold** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe repositorio remoto propio. Los archivos locales son controlados por el jugador; los recibidos para soporte requerirán retención y borrado.

**Regla de Cartridge & Cloud.** Conservar solo mientras sea necesario. La seudonimización no justifica retención indefinida. Los derechos deben ser ejercitables y verificables.

**Procedimiento operativo.**
1. Asignar plazo y trigger de borrado.
2. Separar backup y producción.
3. Implementar búsqueda/export/delete.
4. Registrar solicitud y respuesta.
5. Registrar específicamente el impacto de `Legal hold` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Retention schedule, deletion log, export sample y rights request record.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-006; PRIV-OFF-009; PRIV-OFF-015`.

El borrado cubre índices, objetos primarios y copias operativas; los backups tienen una ventana documentada y no se restauran para reactivar datos que debían eliminarse.

## 118. Derechos del usuario

Este capítulo pertenece al bloque **Retención, eliminación y derechos**. Su objetivo es convertir **derechos del usuario** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Valve gestiona derechos sobre datos Steam mediante su Privacy Dashboard. VRM Games deberá gestionar solo los datos propios que llegue a controlar.

**Regla de Cartridge & Cloud.** Proporcionar canal único, verificar identidad proporcionalmente y no redirigir a Valve cuando la solicitud afecta datos propios.

**Procedimiento operativo.**
1. Asignar plazo y trigger de borrado.
2. Separar backup y producción.
3. Implementar búsqueda/export/delete.
4. Registrar solicitud y respuesta.
5. Registrar específicamente el impacto de `Derechos del usuario` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Rights workflow, identity checklist, response template and log.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-006; PRIV-OFF-009; PRIV-OFF-015`.

La verificación de identidad es proporcional: no se pide documento oficial cuando basta con responder desde el canal o cuenta ya vinculada. Se evita generar más datos para atender un derecho.

## 119. Acceso

Este capítulo pertenece al bloque **Retención, eliminación y derechos**. Su objetivo es convertir **acceso** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe repositorio remoto propio. Los archivos locales son controlados por el jugador; los recibidos para soporte requerirán retención y borrado.

**Regla de Cartridge & Cloud.** Conservar solo mientras sea necesario. La seudonimización no justifica retención indefinida. Los derechos deben ser ejercitables y verificables.

**Procedimiento operativo.**
1. Asignar plazo y trigger de borrado.
2. Separar backup y producción.
3. Implementar búsqueda/export/delete.
4. Registrar solicitud y respuesta.
5. Registrar específicamente el impacto de `Acceso` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Retention schedule, deletion log, export sample y rights request record.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-006; PRIV-OFF-009; PRIV-OFF-015`.

Los controles incluyen least privilege, MFA, segregación de entornos, inventario de secretos, rotación, logs de acceso, restauración y simulacros, con evidencia fechada.

## 120. Rectificación

Este capítulo pertenece al bloque **Retención, eliminación y derechos**. Su objetivo es convertir **rectificación** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe repositorio remoto propio. Los archivos locales son controlados por el jugador; los recibidos para soporte requerirán retención y borrado.

**Regla de Cartridge & Cloud.** Conservar solo mientras sea necesario. La seudonimización no justifica retención indefinida. Los derechos deben ser ejercitables y verificables.

**Procedimiento operativo.**
1. Asignar plazo y trigger de borrado.
2. Separar backup y producción.
3. Implementar búsqueda/export/delete.
4. Registrar solicitud y respuesta.
5. Registrar específicamente el impacto de `Rectificación` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Retention schedule, deletion log, export sample y rights request record.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-006; PRIV-OFF-009; PRIV-OFF-015`.

La verificación de identidad es proporcional: no se pide documento oficial cuando basta con responder desde el canal o cuenta ya vinculada. Se evita generar más datos para atender un derecho.

## 121. Supresión

Este capítulo pertenece al bloque **Retención, eliminación y derechos**. Su objetivo es convertir **supresión** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe repositorio remoto propio. Los archivos locales son controlados por el jugador; los recibidos para soporte requerirán retención y borrado.

**Regla de Cartridge & Cloud.** Conservar solo mientras sea necesario. La seudonimización no justifica retención indefinida. Los derechos deben ser ejercitables y verificables.

**Procedimiento operativo.**
1. Asignar plazo y trigger de borrado.
2. Separar backup y producción.
3. Implementar búsqueda/export/delete.
4. Registrar solicitud y respuesta.
5. Registrar específicamente el impacto de `Supresión` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Retention schedule, deletion log, export sample y rights request record.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-006; PRIV-OFF-009; PRIV-OFF-015`.

El borrado cubre índices, objetos primarios y copias operativas; los backups tienen una ventana documentada y no se restauran para reactivar datos que debían eliminarse.

## 122. Restricción

Este capítulo pertenece al bloque **Retención, eliminación y derechos**. Su objetivo es convertir **restricción** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe repositorio remoto propio. Los archivos locales son controlados por el jugador; los recibidos para soporte requerirán retención y borrado.

**Regla de Cartridge & Cloud.** Conservar solo mientras sea necesario. La seudonimización no justifica retención indefinida. Los derechos deben ser ejercitables y verificables.

**Procedimiento operativo.**
1. Asignar plazo y trigger de borrado.
2. Separar backup y producción.
3. Implementar búsqueda/export/delete.
4. Registrar solicitud y respuesta.
5. Registrar específicamente el impacto de `Restricción` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Retention schedule, deletion log, export sample y rights request record.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-006; PRIV-OFF-009; PRIV-OFF-015`.

## 123. Portabilidad

Este capítulo pertenece al bloque **Retención, eliminación y derechos**. Su objetivo es convertir **portabilidad** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe repositorio remoto propio. Los archivos locales son controlados por el jugador; los recibidos para soporte requerirán retención y borrado.

**Regla de Cartridge & Cloud.** Conservar solo mientras sea necesario. La seudonimización no justifica retención indefinida. Los derechos deben ser ejercitables y verificables.

**Procedimiento operativo.**
1. Asignar plazo y trigger de borrado.
2. Separar backup y producción.
3. Implementar búsqueda/export/delete.
4. Registrar solicitud y respuesta.
5. Registrar específicamente el impacto de `Portabilidad` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Retention schedule, deletion log, export sample y rights request record.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-006; PRIV-OFF-009; PRIV-OFF-015`.

La verificación de identidad es proporcional: no se pide documento oficial cuando basta con responder desde el canal o cuenta ya vinculada. Se evita generar más datos para atender un derecho.

## 124. Oposición

Este capítulo pertenece al bloque **Retención, eliminación y derechos**. Su objetivo es convertir **oposición** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe repositorio remoto propio. Los archivos locales son controlados por el jugador; los recibidos para soporte requerirán retención y borrado.

**Regla de Cartridge & Cloud.** Conservar solo mientras sea necesario. La seudonimización no justifica retención indefinida. Los derechos deben ser ejercitables y verificables.

**Procedimiento operativo.**
1. Asignar plazo y trigger de borrado.
2. Separar backup y producción.
3. Implementar búsqueda/export/delete.
4. Registrar solicitud y respuesta.
5. Registrar específicamente el impacto de `Oposición` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Retention schedule, deletion log, export sample y rights request record.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-006; PRIV-OFF-009; PRIV-OFF-015`.

La verificación de identidad es proporcional: no se pide documento oficial cuando basta con responder desde el canal o cuenta ya vinculada. Se evita generar más datos para atender un derecho.

## 125. Retirada de consentimiento

Este capítulo pertenece al bloque **Retención, eliminación y derechos**. Su objetivo es convertir **retirada de consentimiento** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe repositorio remoto propio. Los archivos locales son controlados por el jugador; los recibidos para soporte requerirán retención y borrado.

**Regla de Cartridge & Cloud.** Conservar solo mientras sea necesario. La seudonimización no justifica retención indefinida. Los derechos deben ser ejercitables y verificables.

**Procedimiento operativo.**
1. Asignar plazo y trigger de borrado.
2. Separar backup y producción.
3. Implementar búsqueda/export/delete.
4. Registrar solicitud y respuesta.
5. Registrar específicamente el impacto de `Retirada de consentimiento` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Retention schedule, deletion log, export sample y rights request record.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-006; PRIV-OFF-009; PRIV-OFF-015`.

La QA verifica simetría entre aceptar y rechazar, ausencia de transmisión previa, persistencia de la elección y efecto real de la revocación, no solo el cambio visual del toggle.

## 126. Verificación de identidad

Este capítulo pertenece al bloque **Retención, eliminación y derechos**. Su objetivo es convertir **verificación de identidad** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe repositorio remoto propio. Los archivos locales son controlados por el jugador; los recibidos para soporte requerirán retención y borrado.

**Regla de Cartridge & Cloud.** Conservar solo mientras sea necesario. La seudonimización no justifica retención indefinida. Los derechos deben ser ejercitables y verificables.

**Procedimiento operativo.**
1. Asignar plazo y trigger de borrado.
2. Separar backup y producción.
3. Implementar búsqueda/export/delete.
4. Registrar solicitud y respuesta.
5. Registrar específicamente el impacto de `Verificación de identidad` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Retention schedule, deletion log, export sample y rights request record.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-006; PRIV-OFF-009; PRIV-OFF-015`.

La verificación de identidad es proporcional: no se pide documento oficial cuando basta con responder desde el canal o cuenta ya vinculada. Se evita generar más datos para atender un derecho.

## 127. Plazos

Este capítulo pertenece al bloque **Retención, eliminación y derechos**. Su objetivo es convertir **plazos** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe repositorio remoto propio. Los archivos locales son controlados por el jugador; los recibidos para soporte requerirán retención y borrado.

**Regla de Cartridge & Cloud.** Conservar solo mientras sea necesario. La seudonimización no justifica retención indefinida. Los derechos deben ser ejercitables y verificables.

**Procedimiento operativo.**
1. Asignar plazo y trigger de borrado.
2. Separar backup y producción.
3. Implementar búsqueda/export/delete.
4. Registrar solicitud y respuesta.
5. Registrar específicamente el impacto de `Plazos` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Retention schedule, deletion log, export sample y rights request record.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-006; PRIV-OFF-009; PRIV-OFF-015`.

## 128. Registro de solicitudes

Este capítulo pertenece al bloque **Retención, eliminación y derechos**. Su objetivo es convertir **registro de solicitudes** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe repositorio remoto propio. Los archivos locales son controlados por el jugador; los recibidos para soporte requerirán retención y borrado.

**Regla de Cartridge & Cloud.** Conservar solo mientras sea necesario. La seudonimización no justifica retención indefinida. Los derechos deben ser ejercitables y verificables.

**Procedimiento operativo.**
1. Asignar plazo y trigger de borrado.
2. Separar backup y producción.
3. Implementar búsqueda/export/delete.
4. Registrar solicitud y respuesta.
5. Registrar específicamente el impacto de `Registro de solicitudes` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Retention schedule, deletion log, export sample y rights request record.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-006; PRIV-OFF-009; PRIV-OFF-015`.

| Campo | Obligatorio |
|---|---|
| Request ID | sí |
| fecha/hora y zona | sí |
| derecho solicitado | sí |
| sistema/fuente | sí |
| verificación usada | sí |
| búsqueda realizada | sí |
| decisión/excepción | sí |
| respuesta y fecha | sí |
| borrado/export evidence | cuando aplique |

## 129. Política de privacidad

Este capítulo pertenece al bloque **Transparencia, políticas, web y comunicaciones**. Su objetivo es convertir **política de privacidad** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe política final. Una release offline sin recolección propia puede usar una política breve y exacta que explique datos locales, Steam/Valve y soporte voluntario.

**Regla de Cartridge & Cloud.** La política cambia antes o simultáneamente con el comportamiento; nunca después de activar un SDK.

**Procedimiento operativo.**
1. Inventariar tratamientos reales.
2. Redactar por capas y lenguaje claro.
3. Publicar ES/EN accesible.
4. Versionar y avisar cambios materiales.
5. Registrar específicamente el impacto de `Política de privacidad` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Versioned ES/EN policy, legal review, public URL and in-game link.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-003; PRIV-OFF-004; PRIV-OFF-008; PRIV-OFF-009`.

La información se presenta por capas: resumen contextual en el punto de recogida, detalle completo accesible y versión archivada. El texto no usa finalidades vagas como “mejorar la experiencia” sin explicar datos y uso.

## 130. Contenido mínimo

Este capítulo pertenece al bloque **Transparencia, políticas, web y comunicaciones**. Su objetivo es convertir **contenido mínimo** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay política final, web analítica, newsletter ni email público. Steam mantiene su propia política para datos de plataforma.

**Regla de Cartridge & Cloud.** La política debe describir el comportamiento real. No se publica texto genérico que anuncie tratamientos inexistentes ni oculte proveedores activos.

**Procedimiento operativo.**
1. Inventariar tratamientos reales.
2. Redactar por capas y lenguaje claro.
3. Publicar ES/EN accesible.
4. Versionar y avisar cambios materiales.
5. Registrar específicamente el impacto de `Contenido mínimo` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Política aprobada, snapshot publicado, copy in-game y registro de versiones.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-003; PRIV-OFF-004; PRIV-OFF-008; PRIV-OFF-009`.

La política final deberá identificar responsable y contacto; categorías y fuentes; finalidades y bases; destinatarios/proveedores; transferencias; conservación; derechos; reclamación; carácter obligatorio/opcional; decisiones automatizadas; menores; seguridad a nivel comprensible; cambios; y relación con Valve/Steam sin atribuirse sus tratamientos.

## 131. Versión y fecha

Este capítulo pertenece al bloque **Transparencia, políticas, web y comunicaciones**. Su objetivo es convertir **versión y fecha** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay política final, web analítica, newsletter ni email público. Steam mantiene su propia política para datos de plataforma.

**Regla de Cartridge & Cloud.** La política debe describir el comportamiento real. No se publica texto genérico que anuncie tratamientos inexistentes ni oculte proveedores activos.

**Procedimiento operativo.**
1. Inventariar tratamientos reales.
2. Redactar por capas y lenguaje claro.
3. Publicar ES/EN accesible.
4. Versionar y avisar cambios materiales.
5. Registrar específicamente el impacto de `Versión y fecha` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Política aprobada, snapshot publicado, copy in-game y registro de versiones.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-003; PRIV-OFF-004; PRIV-OFF-008; PRIV-OFF-009`.

## 132. Idiomas de la política

Este capítulo pertenece al bloque **Transparencia, políticas, web y comunicaciones**. Su objetivo es convertir **idiomas de la política** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay política final, web analítica, newsletter ni email público. Steam mantiene su propia política para datos de plataforma.

**Regla de Cartridge & Cloud.** La política debe describir el comportamiento real. No se publica texto genérico que anuncie tratamientos inexistentes ni oculte proveedores activos.

**Procedimiento operativo.**
1. Inventariar tratamientos reales.
2. Redactar por capas y lenguaje claro.
3. Publicar ES/EN accesible.
4. Versionar y avisar cambios materiales.
5. Registrar específicamente el impacto de `Idiomas de la política` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Política aprobada, snapshot publicado, copy in-game y registro de versiones.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-003; PRIV-OFF-004; PRIV-OFF-008; PRIV-OFF-009`.

La información se presenta por capas: resumen contextual en el punto de recogida, detalle completo accesible y versión archivada. El texto no usa finalidades vagas como “mejorar la experiencia” sin explicar datos y uso.

## 133. Accesibilidad de la política

Este capítulo pertenece al bloque **Transparencia, políticas, web y comunicaciones**. Su objetivo es convertir **accesibilidad de la política** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay política final, web analítica, newsletter ni email público. Steam mantiene su propia política para datos de plataforma.

**Regla de Cartridge & Cloud.** La política debe describir el comportamiento real. No se publica texto genérico que anuncie tratamientos inexistentes ni oculte proveedores activos.

**Procedimiento operativo.**
1. Inventariar tratamientos reales.
2. Redactar por capas y lenguaje claro.
3. Publicar ES/EN accesible.
4. Versionar y avisar cambios materiales.
5. Registrar específicamente el impacto de `Accesibilidad de la política` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Política aprobada, snapshot publicado, copy in-game y registro de versiones.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-003; PRIV-OFF-004; PRIV-OFF-008; PRIV-OFF-009`.

La información se presenta por capas: resumen contextual en el punto de recogida, detalle completo accesible y versión archivada. El texto no usa finalidades vagas como “mejorar la experiencia” sin explicar datos y uso.

## 134. Store page

Este capítulo pertenece al bloque **Transparencia, políticas, web y comunicaciones**. Su objetivo es convertir **store page** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay política final, web analítica, newsletter ni email público. Steam mantiene su propia política para datos de plataforma.

**Regla de Cartridge & Cloud.** La política debe describir el comportamiento real. No se publica texto genérico que anuncie tratamientos inexistentes ni oculte proveedores activos.

**Procedimiento operativo.**
1. Inventariar tratamientos reales.
2. Redactar por capas y lenguaje claro.
3. Publicar ES/EN accesible.
4. Versionar y avisar cambios materiales.
5. Registrar específicamente el impacto de `Store page` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Política aprobada, snapshot publicado, copy in-game y registro de versiones.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-003; PRIV-OFF-004; PRIV-OFF-008; PRIV-OFF-009`.

La información se presenta por capas: resumen contextual en el punto de recogida, detalle completo accesible y versión archivada. El texto no usa finalidades vagas como “mejorar la experiencia” sin explicar datos y uso.

## 135. Dentro del juego

Este capítulo pertenece al bloque **Transparencia, políticas, web y comunicaciones**. Su objetivo es convertir **dentro del juego** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay política final, web analítica, newsletter ni email público. Steam mantiene su propia política para datos de plataforma.

**Regla de Cartridge & Cloud.** La política debe describir el comportamiento real. No se publica texto genérico que anuncie tratamientos inexistentes ni oculte proveedores activos.

**Procedimiento operativo.**
1. Inventariar tratamientos reales.
2. Redactar por capas y lenguaje claro.
3. Publicar ES/EN accesible.
4. Versionar y avisar cambios materiales.
5. Registrar específicamente el impacto de `Dentro del juego` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Política aprobada, snapshot publicado, copy in-game y registro de versiones.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-003; PRIV-OFF-004; PRIV-OFF-008; PRIV-OFF-009`.

La información se presenta por capas: resumen contextual en el punto de recogida, detalle completo accesible y versión archivada. El texto no usa finalidades vagas como “mejorar la experiencia” sin explicar datos y uso.

## 136. Website

Este capítulo pertenece al bloque **Transparencia, políticas, web y comunicaciones**. Su objetivo es convertir **website** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay política final, web analítica, newsletter ni email público. Steam mantiene su propia política para datos de plataforma.

**Regla de Cartridge & Cloud.** La política debe describir el comportamiento real. No se publica texto genérico que anuncie tratamientos inexistentes ni oculte proveedores activos.

**Procedimiento operativo.**
1. Inventariar tratamientos reales.
2. Redactar por capas y lenguaje claro.
3. Publicar ES/EN accesible.
4. Versionar y avisar cambios materiales.
5. Registrar específicamente el impacto de `Website` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Política aprobada, snapshot publicado, copy in-game y registro de versiones.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-003; PRIV-OFF-004; PRIV-OFF-008; PRIV-OFF-009`.

La información se presenta por capas: resumen contextual en el punto de recogida, detalle completo accesible y versión archivada. El texto no usa finalidades vagas como “mejorar la experiencia” sin explicar datos y uso.

## 137. Soporte

Este capítulo pertenece al bloque **Transparencia, políticas, web y comunicaciones**. Su objetivo es convertir **soporte** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay política final, web analítica, newsletter ni email público. Steam mantiene su propia política para datos de plataforma.

**Regla de Cartridge & Cloud.** La política debe describir el comportamiento real. No se publica texto genérico que anuncie tratamientos inexistentes ni oculte proveedores activos.

**Procedimiento operativo.**
1. Inventariar tratamientos reales.
2. Redactar por capas y lenguaje claro.
3. Publicar ES/EN accesible.
4. Versionar y avisar cambios materiales.
5. Registrar específicamente el impacto de `Soporte` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Política aprobada, snapshot publicado, copy in-game y registro de versiones.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-003; PRIV-OFF-004; PRIV-OFF-008; PRIV-OFF-009`.

Los adjuntos voluntarios se consideran potencialmente identificables, se almacenan fuera del repositorio y se vinculan a un ticket mediante un ID interno, no mediante el nombre público del jugador.

## 138. Actualizaciones de política

Este capítulo pertenece al bloque **Transparencia, políticas, web y comunicaciones**. Su objetivo es convertir **actualizaciones de política** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay política final, web analítica, newsletter ni email público. Steam mantiene su propia política para datos de plataforma.

**Regla de Cartridge & Cloud.** La política debe describir el comportamiento real. No se publica texto genérico que anuncie tratamientos inexistentes ni oculte proveedores activos.

**Procedimiento operativo.**
1. Inventariar tratamientos reales.
2. Redactar por capas y lenguaje claro.
3. Publicar ES/EN accesible.
4. Versionar y avisar cambios materiales.
5. Registrar específicamente el impacto de `Actualizaciones de política` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Política aprobada, snapshot publicado, copy in-game y registro de versiones.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-003; PRIV-OFF-004; PRIV-OFF-008; PRIV-OFF-009`.

La información se presenta por capas: resumen contextual en el punto de recogida, detalle completo accesible y versión archivada. El texto no usa finalidades vagas como “mejorar la experiencia” sin explicar datos y uso.

## 139. Aviso de cambios

Este capítulo pertenece al bloque **Transparencia, políticas, web y comunicaciones**. Su objetivo es convertir **aviso de cambios** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay política final, web analítica, newsletter ni email público. Steam mantiene su propia política para datos de plataforma.

**Regla de Cartridge & Cloud.** La política debe describir el comportamiento real. No se publica texto genérico que anuncie tratamientos inexistentes ni oculte proveedores activos.

**Procedimiento operativo.**
1. Inventariar tratamientos reales.
2. Redactar por capas y lenguaje claro.
3. Publicar ES/EN accesible.
4. Versionar y avisar cambios materiales.
5. Registrar específicamente el impacto de `Aviso de cambios` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Política aprobada, snapshot publicado, copy in-game y registro de versiones.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-003; PRIV-OFF-004; PRIV-OFF-008; PRIV-OFF-009`.

La información se presenta por capas: resumen contextual en el punto de recogida, detalle completo accesible y versión archivada. El texto no usa finalidades vagas como “mejorar la experiencia” sin explicar datos y uso.

## 140. Cookies

Este capítulo pertenece al bloque **Transparencia, políticas, web y comunicaciones**. Su objetivo es convertir **cookies** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay web documentada. Una futura web estática puede evitar cookies no esenciales; embeds, analytics, newsletter o pixels cambian el análisis.

**Regla de Cartridge & Cloud.** Preferir cero tracking. Si existen tecnologías no necesarias, ofrecer información y elección válida según LSSI/AEPD.

**Procedimiento operativo.**
1. Inventariar tratamientos reales.
2. Redactar por capas y lenguaje claro.
3. Publicar ES/EN accesible.
4. Versionar y avisar cambios materiales.
5. Registrar específicamente el impacto de `Cookies` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Cookie inventory, scanner, consent test and preference log.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-003; PRIV-OFF-004; PRIV-OFF-008; PRIV-OFF-009`.

## 141. Website analytics

Este capítulo pertenece al bloque **Transparencia, políticas, web y comunicaciones**. Su objetivo es convertir **website analytics** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No está documentado. Steam dejó de soportar Google Analytics en store pages y ofrece reporting agregado propio.

**Regla de Cartridge & Cloud.** Para la web propia, comenzar sin analytics o con medición privacy-preserving evaluada; no copiar GA por defecto.

**Procedimiento operativo.**
1. Inventariar tratamientos reales.
2. Redactar por capas y lenguaje claro.
3. Publicar ES/EN accesible.
4. Versionar y avisar cambios materiales.
5. Registrar específicamente el impacto de `Website analytics` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Website traffic capture, cookie scan, provider assessment and policy.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-003; PRIV-OFF-004; PRIV-OFF-008; PRIV-OFF-009`.

La ficha de métrica documenta pregunta, decisión, población, denominador, ventana, timezone, sesgo, coste de privacidad y condición de retirada; sin esa ficha el evento no puede abrirse. La información se presenta por capas: resumen contextual en el punto de recogida, detalle completo accesible y versión archivada. El texto no usa finalidades vagas como “mejorar la experiencia” sin explicar datos y uso.

## 142. Newsletter

Este capítulo pertenece al bloque **Transparencia, políticas, web y comunicaciones**. Su objetivo es convertir **newsletter** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay política final, web analítica, newsletter ni email público. Steam mantiene su propia política para datos de plataforma.

**Regla de Cartridge & Cloud.** La política debe describir el comportamiento real. No se publica texto genérico que anuncie tratamientos inexistentes ni oculte proveedores activos.

**Procedimiento operativo.**
1. Inventariar tratamientos reales.
2. Redactar por capas y lenguaje claro.
3. Publicar ES/EN accesible.
4. Versionar y avisar cambios materiales.
5. Registrar específicamente el impacto de `Newsletter` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Política aprobada, snapshot publicado, copy in-game y registro de versiones.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-003; PRIV-OFF-004; PRIV-OFF-008; PRIV-OFF-009`.

## 143. Marketing

Este capítulo pertenece al bloque **Transparencia, políticas, web y comunicaciones**. Su objetivo es convertir **marketing** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay política final, web analítica, newsletter ni email público. Steam mantiene su propia política para datos de plataforma.

**Regla de Cartridge & Cloud.** La política debe describir el comportamiento real. No se publica texto genérico que anuncie tratamientos inexistentes ni oculte proveedores activos.

**Procedimiento operativo.**
1. Inventariar tratamientos reales.
2. Redactar por capas y lenguaje claro.
3. Publicar ES/EN accesible.
4. Versionar y avisar cambios materiales.
5. Registrar específicamente el impacto de `Marketing` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Política aprobada, snapshot publicado, copy in-game y registro de versiones.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-003; PRIV-OFF-004; PRIV-OFF-008; PRIV-OFF-009`.

## 144. Community management

Este capítulo pertenece al bloque **Transparencia, políticas, web y comunicaciones**. Su objetivo es convertir **community management** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay política final, web analítica, newsletter ni email público. Steam mantiene su propia política para datos de plataforma.

**Regla de Cartridge & Cloud.** La política debe describir el comportamiento real. No se publica texto genérico que anuncie tratamientos inexistentes ni oculte proveedores activos.

**Procedimiento operativo.**
1. Inventariar tratamientos reales.
2. Redactar por capas y lenguaje claro.
3. Publicar ES/EN accesible.
4. Versionar y avisar cambios materiales.
5. Registrar específicamente el impacto de `Community management` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Política aprobada, snapshot publicado, copy in-game y registro de versiones.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-003; PRIV-OFF-004; PRIV-OFF-008; PRIV-OFF-009`.

## 145. Moderación

Este capítulo pertenece al bloque **Transparencia, políticas, web y comunicaciones**. Su objetivo es convertir **moderación** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay política final, web analítica, newsletter ni email público. Steam mantiene su propia política para datos de plataforma.

**Regla de Cartridge & Cloud.** La política debe describir el comportamiento real. No se publica texto genérico que anuncie tratamientos inexistentes ni oculte proveedores activos.

**Procedimiento operativo.**
1. Inventariar tratamientos reales.
2. Redactar por capas y lenguaje claro.
3. Publicar ES/EN accesible.
4. Versionar y avisar cambios materiales.
5. Registrar específicamente el impacto de `Moderación` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Política aprobada, snapshot publicado, copy in-game y registro de versiones.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-003; PRIV-OFF-004; PRIV-OFF-008; PRIV-OFF-009`.

## 146. Evidencia de consentimiento

Este capítulo pertenece al bloque **Transparencia, políticas, web y comunicaciones**. Su objetivo es convertir **evidencia de consentimiento** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay política final, web analítica, newsletter ni email público. Steam mantiene su propia política para datos de plataforma.

**Regla de Cartridge & Cloud.** La política debe describir el comportamiento real. No se publica texto genérico que anuncie tratamientos inexistentes ni oculte proveedores activos.

**Procedimiento operativo.**
1. Inventariar tratamientos reales.
2. Redactar por capas y lenguaje claro.
3. Publicar ES/EN accesible.
4. Versionar y avisar cambios materiales.
5. Registrar específicamente el impacto de `Evidencia de consentimiento` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Política aprobada, snapshot publicado, copy in-game y registro de versiones.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-003; PRIV-OFF-004; PRIV-OFF-008; PRIV-OFF-009`.

La QA verifica simetría entre aceptar y rechazar, ausencia de transmisión previa, persistencia de la elección y efecto real de la revocación, no solo el cambio visual del toggle.

## 147. Seguridad técnica y organizativa

Este capítulo pertenece al bloque **Seguridad, riesgo, auditoría y calidad**. Su objetivo es convertir **seguridad técnica y organizativa** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay secretos o endpoints de producto observados; sí existen source packages, settings y futura evidencia de soporte que deben protegerse.

**Regla de Cartridge & Cloud.** Las medidas se ajustan al riesgo y cubren confidencialidad, integridad, disponibilidad, restauración y evaluación regular.

**Procedimiento operativo.**
1. Aplicar acceso mínimo y MFA.
2. Separar secretos y código.
3. Probar redacción, borrado y recuperación.
4. Mantener RAT y riesgo.
5. Simular incidente/brecha.
6. Registrar específicamente el impacto de `Seguridad técnica y organizativa` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Security checklist, audit log, incident drill, RAT/EIPD y test report.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007; PRIV-OFF-016`.

Los controles incluyen least privilege, MFA, segregación de entornos, inventario de secretos, rotación, logs de acceso, restauración y simulacros, con evidencia fechada.

## 148. Control de acceso

Este capítulo pertenece al bloque **Seguridad, riesgo, auditoría y calidad**. Su objetivo es convertir **control de acceso** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay secretos o endpoints de producto observados; sí existen source packages, settings y futura evidencia de soporte que deben protegerse.

**Regla de Cartridge & Cloud.** Las medidas se ajustan al riesgo y cubren confidencialidad, integridad, disponibilidad, restauración y evaluación regular.

**Procedimiento operativo.**
1. Aplicar acceso mínimo y MFA.
2. Separar secretos y código.
3. Probar redacción, borrado y recuperación.
4. Mantener RAT y riesgo.
5. Simular incidente/brecha.
6. Registrar específicamente el impacto de `Control de acceso` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Security checklist, audit log, incident drill, RAT/EIPD y test report.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007; PRIV-OFF-016`.

Los controles incluyen least privilege, MFA, segregación de entornos, inventario de secretos, rotación, logs de acceso, restauración y simulacros, con evidencia fechada.

## 149. Cifrado

Este capítulo pertenece al bloque **Seguridad, riesgo, auditoría y calidad**. Su objetivo es convertir **cifrado** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay secretos o endpoints de producto observados; sí existen source packages, settings y futura evidencia de soporte que deben protegerse.

**Regla de Cartridge & Cloud.** Las medidas se ajustan al riesgo y cubren confidencialidad, integridad, disponibilidad, restauración y evaluación regular.

**Procedimiento operativo.**
1. Aplicar acceso mínimo y MFA.
2. Separar secretos y código.
3. Probar redacción, borrado y recuperación.
4. Mantener RAT y riesgo.
5. Simular incidente/brecha.
6. Registrar específicamente el impacto de `Cifrado` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Security checklist, audit log, incident drill, RAT/EIPD y test report.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007; PRIV-OFF-016`.

Los controles incluyen least privilege, MFA, segregación de entornos, inventario de secretos, rotación, logs de acceso, restauración y simulacros, con evidencia fechada.

## 150. Secretos

Este capítulo pertenece al bloque **Seguridad, riesgo, auditoría y calidad**. Su objetivo es convertir **secretos** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay secretos o endpoints de producto observados; sí existen source packages, settings y futura evidencia de soporte que deben protegerse.

**Regla de Cartridge & Cloud.** Las medidas se ajustan al riesgo y cubren confidencialidad, integridad, disponibilidad, restauración y evaluación regular.

**Procedimiento operativo.**
1. Aplicar acceso mínimo y MFA.
2. Separar secretos y código.
3. Probar redacción, borrado y recuperación.
4. Mantener RAT y riesgo.
5. Simular incidente/brecha.
6. Registrar específicamente el impacto de `Secretos` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Security checklist, audit log, incident drill, RAT/EIPD y test report.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007; PRIV-OFF-016`.

Los controles incluyen least privilege, MFA, segregación de entornos, inventario de secretos, rotación, logs de acceso, restauración y simulacros, con evidencia fechada.

## 151. API keys

Este capítulo pertenece al bloque **Seguridad, riesgo, auditoría y calidad**. Su objetivo es convertir **api keys** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay secretos o endpoints de producto observados; sí existen source packages, settings y futura evidencia de soporte que deben protegerse.

**Regla de Cartridge & Cloud.** Las medidas se ajustan al riesgo y cubren confidencialidad, integridad, disponibilidad, restauración y evaluación regular.

**Procedimiento operativo.**
1. Aplicar acceso mínimo y MFA.
2. Separar secretos y código.
3. Probar redacción, borrado y recuperación.
4. Mantener RAT y riesgo.
5. Simular incidente/brecha.
6. Registrar específicamente el impacto de `API keys` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Security checklist, audit log, incident drill, RAT/EIPD y test report.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007; PRIV-OFF-016`.

Los controles incluyen least privilege, MFA, segregación de entornos, inventario de secretos, rotación, logs de acceso, restauración y simulacros, con evidencia fechada.

## 152. Variables de entorno

Este capítulo pertenece al bloque **Seguridad, riesgo, auditoría y calidad**. Su objetivo es convertir **variables de entorno** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay secretos o endpoints de producto observados; sí existen source packages, settings y futura evidencia de soporte que deben protegerse.

**Regla de Cartridge & Cloud.** Las medidas se ajustan al riesgo y cubren confidencialidad, integridad, disponibilidad, restauración y evaluación regular.

**Procedimiento operativo.**
1. Aplicar acceso mínimo y MFA.
2. Separar secretos y código.
3. Probar redacción, borrado y recuperación.
4. Mantener RAT y riesgo.
5. Simular incidente/brecha.
6. Registrar específicamente el impacto de `Variables de entorno` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Security checklist, audit log, incident drill, RAT/EIPD y test report.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007; PRIV-OFF-016`.

## 153. Logs de infraestructura

Este capítulo pertenece al bloque **Seguridad, riesgo, auditoría y calidad**. Su objetivo es convertir **logs de infraestructura** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay secretos o endpoints de producto observados; sí existen source packages, settings y futura evidencia de soporte que deben protegerse.

**Regla de Cartridge & Cloud.** Las medidas se ajustan al riesgo y cubren confidencialidad, integridad, disponibilidad, restauración y evaluación regular.

**Procedimiento operativo.**
1. Aplicar acceso mínimo y MFA.
2. Separar secretos y código.
3. Probar redacción, borrado y recuperación.
4. Mantener RAT y riesgo.
5. Simular incidente/brecha.
6. Registrar específicamente el impacto de `Logs de infraestructura` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Security checklist, audit log, incident drill, RAT/EIPD y test report.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007; PRIV-OFF-016`.

Los adjuntos voluntarios se consideran potencialmente identificables, se almacenan fuera del repositorio y se vinculan a un ticket mediante un ID interno, no mediante el nombre público del jugador.

## 154. Incident response

Este capítulo pertenece al bloque **Seguridad, riesgo, auditoría y calidad**. Su objetivo es convertir **incident response** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay secretos o endpoints de producto observados; sí existen source packages, settings y futura evidencia de soporte que deben protegerse.

**Regla de Cartridge & Cloud.** Las medidas se ajustan al riesgo y cubren confidencialidad, integridad, disponibilidad, restauración y evaluación regular.

**Procedimiento operativo.**
1. Aplicar acceso mínimo y MFA.
2. Separar secretos y código.
3. Probar redacción, borrado y recuperación.
4. Mantener RAT y riesgo.
5. Simular incidente/brecha.
6. Registrar específicamente el impacto de `Incident response` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Security checklist, audit log, incident drill, RAT/EIPD y test report.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007; PRIV-OFF-016`.

Los controles incluyen least privilege, MFA, segregación de entornos, inventario de secretos, rotación, logs de acceso, restauración y simulacros, con evidencia fechada.

## 155. Data breach

Este capítulo pertenece al bloque **Seguridad, riesgo, auditoría y calidad**. Su objetivo es convertir **data breach** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe repositorio remoto de jugadores, pero un buzón, ticketing, crash vendor o Cloud puede sufrir brecha. El RGPD exige documentar todas y notificar cuando proceda, con referencia de 72 horas para la autoridad cuando haya riesgo.

**Regla de Cartridge & Cloud.** Activar canal interno, preservar evidencia, contener, evaluar riesgo, decidir notificación y comunicar en lenguaje claro cuando corresponda.

**Procedimiento operativo.**
1. Aplicar acceso mínimo y MFA.
2. Separar secretos y código.
3. Probar redacción, borrado y recuperación.
4. Mantener RAT y riesgo.
5. Simular incidente/brecha.
6. Registrar específicamente el impacto de `Data breach` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Breach register, timeline, risk assessment, authority/user drafts and postmortem.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007; PRIV-OFF-016`.

Los controles incluyen least privilege, MFA, segregación de entornos, inventario de secretos, rotación, logs de acceso, restauración y simulacros, con evidencia fechada.

## 156. Evaluación de impacto

Este capítulo pertenece al bloque **Seguridad, riesgo, auditoría y calidad**. Su objetivo es convertir **evaluación de impacto** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No se ha realizado EIPD porque no existe tratamiento alto riesgo activo. Profiling, menores, telemetría extensa, biometría o combinación a gran escala serían triggers claros de revisión.

**Regla de Cartridge & Cloud.** La EIPD se realiza antes de abrir el tratamiento y puede concluir que no debe implementarse.

**Procedimiento operativo.**
1. Aplicar acceso mínimo y MFA.
2. Separar secretos y código.
3. Probar redacción, borrado y recuperación.
4. Mantener RAT y riesgo.
5. Simular incidente/brecha.
6. Registrar específicamente el impacto de `Evaluación de impacto` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Completed EIPD or documented screening and residual-risk decision.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007; PRIV-OFF-016`.

## 157. Registro de actividades

Este capítulo pertenece al bloque **Seguridad, riesgo, auditoría y calidad**. Su objetivo es convertir **registro de actividades** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No existe RAT formal. Debe crearse para soporte, web, colaboradores, Steamworks data y cualquier proveedor que procese datos personales.

**Regla de Cartridge & Cloud.** Una actividad por finalidad coherente; incluir categorías, destinatarios, transferencias, plazos y medidas.

**Procedimiento operativo.**
1. Aplicar acceso mínimo y MFA.
2. Separar secretos y código.
3. Probar redacción, borrado y recuperación.
4. Mantener RAT y riesgo.
5. Simular incidente/brecha.
6. Registrar específicamente el impacto de `Registro de actividades` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** RAT export and owner review.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007; PRIV-OFF-016`.

## 158. Inventario de datos

Este capítulo pertenece al bloque **Seguridad, riesgo, auditoría y calidad**. Su objetivo es convertir **inventario de datos** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay secretos o endpoints de producto observados; sí existen source packages, settings y futura evidencia de soporte que deben protegerse.

**Regla de Cartridge & Cloud.** Las medidas se ajustan al riesgo y cubren confidencialidad, integridad, disponibilidad, restauración y evaluación regular.

**Procedimiento operativo.**
1. Aplicar acceso mínimo y MFA.
2. Separar secretos y código.
3. Probar redacción, borrado y recuperación.
4. Mantener RAT y riesgo.
5. Simular incidente/brecha.
6. Registrar específicamente el impacto de `Inventario de datos` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Security checklist, audit log, incident drill, RAT/EIPD y test report.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007; PRIV-OFF-016`.

Los informes de Steam se tratan como una fuente separada: el estudio registra qué campos recibe, si son agregados y quién tiene permiso; no infiere acceso a datos individuales por el mero hecho de usar Steamworks.

## 159. Data-flow diagrams

Este capítulo pertenece al bloque **Seguridad, riesgo, auditoría y calidad**. Su objetivo es convertir **data-flow diagrams** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay secretos o endpoints de producto observados; sí existen source packages, settings y futura evidencia de soporte que deben protegerse.

**Regla de Cartridge & Cloud.** Las medidas se ajustan al riesgo y cubren confidencialidad, integridad, disponibilidad, restauración y evaluación regular.

**Procedimiento operativo.**
1. Aplicar acceso mínimo y MFA.
2. Separar secretos y código.
3. Probar redacción, borrado y recuperación.
4. Mantener RAT y riesgo.
5. Simular incidente/brecha.
6. Registrar específicamente el impacto de `Data-flow diagrams` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Security checklist, audit log, incident drill, RAT/EIPD y test report.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007; PRIV-OFF-016`.

```text
CURRENT
Player device -> local save / PlayerPrefs / Player.log
Player device -X-> VRM Games backend (no existe)
Player device -X-> analytics/crash endpoint (no integrado)

FUTURE SUPPORT
Player -> support email/ticket -> restricted case storage -> deletion

FUTURE OPTIONAL TELEMETRY
Game -> redaction/validation -> endpoint -> raw TTL -> aggregate -> deletion
```

## 160. Matriz de proveedores

Este capítulo pertenece al bloque **Seguridad, riesgo, auditoría y calidad**. Su objetivo es convertir **matriz de proveedores** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay secretos o endpoints de producto observados; sí existen source packages, settings y futura evidencia de soporte que deben protegerse.

**Regla de Cartridge & Cloud.** Las medidas se ajustan al riesgo y cubren confidencialidad, integridad, disponibilidad, restauración y evaluación regular.

**Procedimiento operativo.**
1. Aplicar acceso mínimo y MFA.
2. Separar secretos y código.
3. Probar redacción, borrado y recuperación.
4. Mantener RAT y riesgo.
5. Simular incidente/brecha.
6. Registrar específicamente el impacto de `Matriz de proveedores` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Security checklist, audit log, incident drill, RAT/EIPD y test report.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007; PRIV-OFF-016`.

El proveedor no se aprueba solo por disponer de una política pública: se revisan contrato, DPA, subprocesadores, localización, reutilización, incidentes, exportación, borrado y plan de salida.

## 161. Contratos

Este capítulo pertenece al bloque **Seguridad, riesgo, auditoría y calidad**. Su objetivo es convertir **contratos** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay secretos o endpoints de producto observados; sí existen source packages, settings y futura evidencia de soporte que deben protegerse.

**Regla de Cartridge & Cloud.** Las medidas se ajustan al riesgo y cubren confidencialidad, integridad, disponibilidad, restauración y evaluación regular.

**Procedimiento operativo.**
1. Aplicar acceso mínimo y MFA.
2. Separar secretos y código.
3. Probar redacción, borrado y recuperación.
4. Mantener RAT y riesgo.
5. Simular incidente/brecha.
6. Registrar específicamente el impacto de `Contratos` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Security checklist, audit log, incident drill, RAT/EIPD y test report.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007; PRIV-OFF-016`.

El proveedor no se aprueba solo por disponer de una política pública: se revisan contrato, DPA, subprocesadores, localización, reutilización, incidentes, exportación, borrado y plan de salida.

## 162. Auditoría

Este capítulo pertenece al bloque **Seguridad, riesgo, auditoría y calidad**. Su objetivo es convertir **auditoría** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay secretos o endpoints de producto observados; sí existen source packages, settings y futura evidencia de soporte que deben protegerse.

**Regla de Cartridge & Cloud.** Las medidas se ajustan al riesgo y cubren confidencialidad, integridad, disponibilidad, restauración y evaluación regular.

**Procedimiento operativo.**
1. Aplicar acceso mínimo y MFA.
2. Separar secretos y código.
3. Probar redacción, borrado y recuperación.
4. Mantener RAT y riesgo.
5. Simular incidente/brecha.
6. Registrar específicamente el impacto de `Auditoría` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Security checklist, audit log, incident drill, RAT/EIPD y test report.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007; PRIV-OFF-016`.

## 163. QA

Este capítulo pertenece al bloque **Seguridad, riesgo, auditoría y calidad**. Su objetivo es convertir **qa** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay secretos o endpoints de producto observados; sí existen source packages, settings y futura evidencia de soporte que deben protegerse.

**Regla de Cartridge & Cloud.** Las medidas se ajustan al riesgo y cubren confidencialidad, integridad, disponibilidad, restauración y evaluación regular.

**Procedimiento operativo.**
1. Aplicar acceso mínimo y MFA.
2. Separar secretos y código.
3. Probar redacción, borrado y recuperación.
4. Mantener RAT y riesgo.
5. Simular incidente/brecha.
6. Registrar específicamente el impacto de `QA` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Security checklist, audit log, incident drill, RAT/EIPD y test report.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007; PRIV-OFF-016`.

## 164. Tests

Este capítulo pertenece al bloque **Seguridad, riesgo, auditoría y calidad**. Su objetivo es convertir **tests** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

HISTORICAL EVIDENCE — infraestructura automatizada retirada: **Estado y contexto.** La baseline `1215 EditMode + 70 PlayMode` no incluye una campaña de privacidad. Se añadirán tests de no transmisión, redacción, consent, deletion, schema y provider-off behavior.

**Regla de Cartridge & Cloud.** Privacidad se valida como comportamiento observable y no solo documentación.

**Procedimiento operativo.**
1. Aplicar acceso mínimo y MFA.
2. Separar secretos y código.
3. Probar redacción, borrado y recuperación.
4. Mantener RAT y riesgo.
5. Simular incidente/brecha.
6. Registrar específicamente el impacto de `Tests` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Automated results, packet capture, clean-machine test and evidence hash.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007; PRIV-OFF-016`.

## 165. Work packages

Este capítulo pertenece al bloque **Seguridad, riesgo, auditoría y calidad**. Su objetivo es convertir **work packages** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** No hay secretos o endpoints de producto observados; sí existen source packages, settings y futura evidencia de soporte que deben protegerse.

**Regla de Cartridge & Cloud.** Las medidas se ajustan al riesgo y cubren confidencialidad, integridad, disponibilidad, restauración y evaluación regular.

**Procedimiento operativo.**
1. Aplicar acceso mínimo y MFA.
2. Separar secretos y código.
3. Probar redacción, borrado y recuperación.
4. Mantener RAT y riesgo.
5. Simular incidente/brecha.
6. Registrar específicamente el impacto de `Work packages` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Security checklist, audit log, incident drill, RAT/EIPD y test report.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007; PRIV-OFF-016`.

| ID | Paquete | Gate |
|---|---|---|
| PRIV-WP-01 | Inventario/RAT inicial | Pre-Steam |
| PRIV-WP-02 | Política ES/EN local-first | H6 / store |
| PRIV-WP-03 | Soporte, notice y retención | Pre-release |
| PRIV-WP-04 | Redacción de logs y adjuntos | Pre-release |
| PRIV-WP-05 | Vendor/DPA template | Before provider |
| PRIV-WP-06 | Rights request workflow | Pre-release |
| PRIV-WP-07 | Breach runbook and drill | Pre-release |
| PRIV-WP-08 | Website/cookie audit | Before website |
| PRIV-WP-09 | Steam data/permissions map | Onboarding |
| PRIV-WP-10 | Cloud privacy gate | Optional feature |
| PRIV-WP-11 | Crash provider gate | Optional feature |
| PRIV-WP-12 | Telemetry experiment gate | Post-launch only if justified |

## 166. Gates

Este capítulo pertenece al bloque **Ejecución, gates y mantenimiento**. Su objetivo es convertir **gates** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Todo sistema online permanece `NOT OPEN`. H6 no exige telemetría; la release puede y debe avanzar sin ella si no aporta valor proporcional.

**Regla de Cartridge & Cloud.** Gate exige finalidad, RAT, legal basis, DPA, policy, security, QA, rollback/kill switch y aprobación manual.

**Procedimiento operativo.**
1. Crear paquete con owner y DoR.
2. Cerrar diseño/contrato/privacidad.
3. Implementar detrás de feature flag.
4. Ejecutar QA y auditoría.
5. Tomar decisión Go/No-Go.
6. Registrar específicamente el impacto de `Gates` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Signed Go/No-Go with evidence pack.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007`.

| Gate | Condiciones mínimas |
|---|---|
| Privacy baseline | RAT, roles, local data map, owner |
| Support | notice, provider, MFA, retention, delete |
| Website | cookie scan, policy, consent if needed |
| Steam APIs | data/API inventory, permissions, secrets, rights |
| Steam Cloud | paths, role, policy, conflict and delete tests |
| Crash SDK | DPA, data map, redaction, retention, opt/control |
| Telemetry | purpose, necessity, schema, base, policy, QA, kill switch |
| Public release | behavior matches policy; no unauthorized endpoints |

## 167. Checklists

Este capítulo pertenece al bloque **Ejecución, gates y mantenimiento**. Su objetivo es convertir **checklists** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** La implementación permanece bloqueada hasta existir finalidad, arquitectura, proveedor, política, seguridad, QA y revisión legal.

**Regla de Cartridge & Cloud.** Ningún SDK, endpoint, cookie, formulario o feature online se incorpora fuera de un work package y gate explícito.

**Procedimiento operativo.**
1. Crear paquete con owner y DoR.
2. Cerrar diseño/contrato/privacidad.
3. Implementar detrás de feature flag.
4. Ejecutar QA y auditoría.
5. Tomar decisión Go/No-Go.
6. Registrar específicamente el impacto de `Checklists` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Work package, checklist, risk acceptance, evidence pack y changelog.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007`.

- [ ] No endpoint/SDK nuevo sin ADR y privacy review.
- [ ] Package/settings scan actualizado.
- [ ] Captura de tráfico de build limpia.
- [ ] Política ES/EN coincide con comportamiento.
- [ ] Retención y borrado probados.
- [ ] Proveedores y subprocesadores registrados.
- [ ] Secrets fuera del cliente/repositorio.
- [ ] Derechos y breach drill ejecutados.
- [ ] Build/commit/checksum archivados.

## 168. Plantillas

Este capítulo pertenece al bloque **Ejecución, gates y mantenimiento**. Su objetivo es convertir **plantillas** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** La implementación permanece bloqueada hasta existir finalidad, arquitectura, proveedor, política, seguridad, QA y revisión legal.

**Regla de Cartridge & Cloud.** Ningún SDK, endpoint, cookie, formulario o feature online se incorpora fuera de un work package y gate explícito.

**Procedimiento operativo.**
1. Crear paquete con owner y DoR.
2. Cerrar diseño/contrato/privacidad.
3. Implementar detrás de feature flag.
4. Ejecutar QA y auditoría.
5. Tomar decisión Go/No-Go.
6. Registrar específicamente el impacto de `Plantillas` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Work package, checklist, risk acceptance, evidence pack y changelog.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007`.

```text
DATA ACTIVITY ID:
Purpose / decision:
Controller / processor roles:
Data categories and sources:
Recipients / transfers:
Legal basis:
Retention and deletion:
Security controls:
Rights workflow:
DPIA screening:
Build / feature flag:
Approval / date:
```

## 169. Riesgos

Este capítulo pertenece al bloque **Ejecución, gates y mantenimiento**. Su objetivo es convertir **riesgos** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** Riesgos principales: activar SDK accidentalmente, confundir módulo con servicio, logs con PII, save uploads, ID estable, proveedor que reutiliza datos, transferencias, política inexacta, Cloud prematuro y brecha sin runbook.

**Regla de Cartridge & Cloud.** Cada riesgo tiene probabilidad, impacto, trigger, owner, mitigación, contingencia y evidencia de cierre.

**Procedimiento operativo.**
1. Crear paquete con owner y DoR.
2. Cerrar diseño/contrato/privacidad.
3. Implementar detrás de feature flag.
4. Ejecutar QA y auditoría.
5. Tomar decisión Go/No-Go.
6. Registrar específicamente el impacto de `Riesgos` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Risk register reviewed per release.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007`.

## 170. Glosario

Este capítulo pertenece al bloque **Ejecución, gates y mantenimiento**. Su objetivo es convertir **glosario** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** La implementación permanece bloqueada hasta existir finalidad, arquitectura, proveedor, política, seguridad, QA y revisión legal.

**Regla de Cartridge & Cloud.** Ningún SDK, endpoint, cookie, formulario o feature online se incorpora fuera de un work package y gate explícito.

**Procedimiento operativo.**
1. Crear paquete con owner y DoR.
2. Cerrar diseño/contrato/privacidad.
3. Implementar detrás de feature flag.
4. Ejecutar QA y auditoría.
5. Tomar decisión Go/No-Go.
6. Registrar específicamente el impacto de `Glosario` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Work package, checklist, risk acceptance, evidence pack y changelog.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007`.

| Término | Definición operativa |
|---|---|
| dato personal | información sobre persona identificada o identificable |
| seudónimo | dato aún personal con vínculo reducido/separado |
| anónimo | no identificable razonablemente tras evaluación |
| telemetría | monitorización estructurada de uso/rendimiento enviada o procesada |
| evento | unidad versionada del esquema de telemetría |
| RAT | registro de actividades de tratamiento |
| EIPD/DPIA | evaluación previa para tratamientos de alto riesgo |
| responsable | decide fines y medios esenciales |
| encargado | trata por cuenta e instrucciones del responsable |
| subprocesador | encargado contratado por otro encargado |

## 171. Historial de cambios

Este capítulo pertenece al bloque **Ejecución, gates y mantenimiento**. Su objetivo es convertir **historial de cambios** en una decisión verificable de producto, no en una declaración genérica de cumplimiento. Se aplica a desarrollo, QA, soporte, Steam, web y cualquier proveedor futuro.

**Estado y contexto.** La implementación permanece bloqueada hasta existir finalidad, arquitectura, proveedor, política, seguridad, QA y revisión legal.

**Regla de Cartridge & Cloud.** Ningún SDK, endpoint, cookie, formulario o feature online se incorpora fuera de un work package y gate explícito.

**Procedimiento operativo.**
1. Crear paquete con owner y DoR.
2. Cerrar diseño/contrato/privacidad.
3. Implementar detrás de feature flag.
4. Ejecutar QA y auditoría.
5. Tomar decisión Go/No-Go.
6. Registrar específicamente el impacto de `Historial de cambios` en el inventario de datos, el riesgo, la política y la build afectada.

**Evidencia mínima.** Work package, checklist, risk acceptance, evidence pack y changelog.

**Referencias oficiales relacionadas:** `PRIV-OFF-001; PRIV-OFF-004; PRIV-OFF-007`.

## Anexo A. Inventario de datos actual

| Superficie | Datos | Ubicación | Recibe VRM Games por defecto | Estado |
|---|---|---|---|---|
| Integrated save | schema, session ID sintético, slot, timestamps, día, cash, inventarios, pedidos, clientes sintéticos, checkout, ledger | `persistentDataPath/IntegratedSaveGames` | no | CURRENT / LOCAL |
| Legacy save skeleton | slot, session ID sintético, timestamps, día, cash | `persistentDataPath/SaveGames` | no | TECHNICAL / LOCAL |
| PlayerPrefs audio | volumen por canal | registro/preferences local Unity | no | CURRENT / LOCAL |
| PlayerPrefs walls | `CC_S16_P1_HideOccludingWalls` | preferences local Unity | no | CURRENT / LOCAL |
| Player.log | eventos, excepciones, stack traces | local Unity | no | CURRENT / LOCAL |
| Build evidence | logs/checksums internos | documentación interna | sí, generado por desarrollo | CURRENT / INTERNAL |
| Support attachments | email, log, save, screenshot, hardware | no existe sistema | no | FUTURE / VOLUNTARY |
| Steam reports | tráfico/UTM/ventas/reembolsos agregados | Steamworks | no AppID | FUTURE PLATFORM |
| SteamID | identificador de plataforma | no integrado | no | NOT OPEN |
| Telemetry events | comportamiento/rendimiento | no endpoint | no | NOT OPEN |
| Crash dumps | memoria/estado | no SDK | no | NOT OPEN |

## Anexo B. Unity Services y paquetes observados

| Elemento | Valor observado | Interpretación prudente |
|---|---|---|
| UnityConnect global | `1` | configuración de conexión del proyecto; revisar por separado del player |
| Insights enabled | `0` | desactivado |
| Engine diagnostics | `1` | habilitado en setting de herramienta; verificar alcance/editor |
| Cloud Diagnostics reporting | `0` | desactivado |
| Unity Analytics | `0` | desactivado |
| Unity Ads | `0` | desactivado |
| Unity Purchasing | `0` | desactivado |
| Performance Reporting | `0` | desactivado |
| Built-in unityanalytics module | `sí` | presencia de módulo no demuestra activación |
| Direct packages | `41` | revisar licencias/settings por release |
| Locked packages | `57` | incluye transitivos |

## Anexo C. Resultado del escaneo de integraciones

| Búsqueda | Hits | Interpretación |
|---|---:|---|
| Steamworks integration | 0 | No encontrado |
| UGS Analytics runtime integration | 0 | No encontrado |
| External analytics SDK | 1 | Revisar lista; no asumir tratamiento sin analizar contexto |
| External crash SDK | 0 | No encontrado |
| Network / HTTP product code | 0 | No encontrado |
| Steam Cloud integration | 0 | No encontrado |
| Device fingerprinting | 0 | No encontrado |
| Email/account fields | 1 | Revisar lista; no asumir tratamiento sin analizar contexto |

Archivos con `PlayerPrefs`: **3**. Archivos con llamadas `Debug.Log*`: **26**. Estas cifras describen código, no transmisiones de red.

## Anexo D. RAT inicial propuesto

| Activity ID | Finalidad | Datos | Fuente | Base a revisar | Destinatarios | Retención | Estado |
|---|---|---|---|---|---|---|---|
| RAT-001 | guardar progreso | estado de juego local | jugador/dispositivo | ejecución local del producto; fuera de recepción del estudio | ninguno | hasta borrado por usuario | CURRENT / LOCAL |
| RAT-002 | preferencias | volumen/occlusion | jugador | ejecución local | ninguno | hasta reset/uninstall | CURRENT / LOCAL |
| RAT-003 | soporte | email, log, save, screenshot, hardware | usuario | contrato/interés/consentimiento según campo, revisar | proveedor email/ticketing | según schedule | PLANNED |
| RAT-004 | Steam store reporting | agregados de tráfico/comercio | Valve | relación partner / términos, revisar | personal autorizado | según Steam/archivo interno | FUTURE |
| RAT-005 | crash diagnostics | crash report/dump | juego/dispositivo | TBD | proveedor crash | TBD | NOT OPEN |
| RAT-006 | gameplay telemetry | eventos estructurados | juego | TBD, opt-in target | analytics processor | TBD | NOT OPEN |
| RAT-007 | Steam Cloud | saves/config por Steam user | dispositivo/Steam | prestación feature, revisar roles | Valve | mientras feature/cuenta | NOT OPEN |
| RAT-008 | newsletter | email/preferencias | usuario | consentimiento | email provider | hasta revocación + evidence | NOT OPEN |

## Anexo E. Matriz de proveedores

| Proveedor/servicio | Uso actual | Datos potenciales | Rol por confirmar | Gate |
|---|---|---|---|---|
| Valve / Steam | futuro storefront | cuenta Steam, commerce, reports | Valve controller; VRM role según dato recibido | Steam onboarding |
| Unity | motor/editor/packages | cuenta de desarrollo, diagnostics de herramienta | según servicio/términos | release/tool audit |
| Email provider | no elegido | email, headers, attachments | processor/controller aspects | support gate |
| Ticketing | no elegido | tickets, logs, saves | processor | support gate |
| Crash provider | no elegido | crash, device, dump | processor/controller reuse risk | crash gate |
| Analytics provider | no elegido | events, identifiers | processor/controller reuse risk | telemetry gate |
| Website host/CDN | no elegido | IP/access logs | processor/controller | website gate |
| Newsletter provider | no elegido | email, consent, engagement | processor | marketing gate |

## Anexo F. Fuentes oficiales verificadas

Las siguientes fuentes se verificaron el **1 de julio de 2026**. Deben revalidarse antes de publicar o activar un tratamiento. La guía AEPD de videojuegos es sectorial y reciente, pero no sustituye el análisis específico del proyecto.

| ID | Fuente | URL | Uso |
|---|---|---|---|
| `PRIV-OFF-001` | RGPD — Reglamento (UE) 2016/679 | https://www.boe.es/buscar/doc.php?id=DOUE-L-2016-80807 | Principios, licitud, transparencia, derechos, diseño, seguridad, brechas, EIPD y responsabilidad. |
| `PRIV-OFF-002` | LOPDGDD — Ley Orgánica 3/2018 | https://www.boe.es/buscar/act.php?id=BOE-A-2018-16673 | Marco español y consentimiento de menores desde los catorce años, con las excepciones legales aplicables. |
| `PRIV-OFF-003` | LSSI-CE — Ley 34/2002 | https://www.boe.es/buscar/act.php?id=BOE-A-2002-13758 | Servicios online, comunicaciones y almacenamiento/acceso en equipos terminales, incluido el marco de cookies. |
| `PRIV-OFF-004` | AEPD / Autoridad Belga — Recomendaciones para videojuegos (2026) | https://www.aepd.es/guias/recomendaciones-industria-videojuego.pdf | Guía sectorial sobre cuentas, telemetría, inferencias, roles, minimización, consentimiento, retención, menores y lifecycle. |
| `PRIV-OFF-005` | AEPD — Nota de publicación de la guía de videojuegos | https://www.aepd.es/prensa-y-comunicacion/notas-de-prensa/aepd-y-autoridad-belga-impulsan-buenas-practicas-sector-videojuego | Contexto, alcance y fecha de la guía sectorial. |
| `PRIV-OFF-006` | EDPB — Anonymisation / Pseudonymisation | https://www.edpb.europa.eu/topics/ai-and-technology/anonymisationpseudonymisation_en | Diferencia entre anonimización y seudonimización; la segunda sigue siendo dato personal. |
| `PRIV-OFF-007` | AEPD — Gestiona RGPD | https://www.aepd.es/guias-y-herramientas/herramientas/gestiona2 | Herramienta de apoyo para RAT, riesgo y EIPD; no reemplaza el análisis responsable. |
| `PRIV-OFF-008` | AEPD — Guía de cookies | https://www.aepd.es/es/documento/guia-cookies.pdf | Criterios para información, consentimiento, rechazo y gestión de preferencias en web. |
| `PRIV-OFF-009` | Valve — Steam Privacy Policy | https://store.steampowered.com/privacy_agreement/ | Tratamientos de Valve, Privacy Dashboard y derechos de usuarios Steam. |
| `PRIV-OFF-010` | Steamworks — Store and Platform Traffic Reporting | https://partner.steamgames.com/doc/marketing/traffic_reporting | Informes agregados de tráfico de la plataforma. |
| `PRIV-OFF-011` | Steamworks — Google Analytics support ended | https://partner.steamgames.com/doc/marketing/google_analytics | Steam dejó de soportar Google Analytics y prioriza reporting agregado con privacidad. |
| `PRIV-OFF-012` | Steamworks — UTM Analytics | https://partner.steamgames.com/doc/marketing/utm_analytics | Métricas agregadas, umbrales y ausencia de SteamID/datos personales en reportes UTM. |
| `PRIV-OFF-013` | Steamworks — Steam Cloud | https://partner.steamgames.com/doc/features/cloud | API y Auto-Cloud, archivos por usuario y sincronización. |
| `PRIV-OFF-014` | Steamworks — Authentication and Ownership | https://partner.steamgames.com/doc/features/auth | Obtención y uso de SteamID cuando se integra autenticación/ownership. |
| `PRIV-OFF-015` | Steamworks Web API — ISteamUser | https://partner.steamgames.com/doc/webapi/ISteamUser | GetDeletedSteamIDs y obligaciones operativas si se almacenan datos ligados a SteamID. |
| `PRIV-OFF-016` | Steamworks — Managing Users | https://partner.steamgames.com/doc/gettingstarted/managing_users | Permisos y control de acceso a datos/reportes en Steamworks. |

## Anexo G. Evidencia técnica hashada

|---|---:|---|

## Anexo H. Escenas de build observadas

| Enabled | Escena | GUID |
|---|---|---|
| sí | `Assets/_Project/Scenes/Bootstrap.unity` | `ada1e52ac6e09b9468e2109ccc7cbfc0` |
| sí | `Assets/_Project/Scenes/MainMenu.unity` | `b00786c6952a55d418cf16503030c766` |
| sí | `Assets/_Project/Scenes/Store.unity` | `45adcce906944f74bad3a0fb7d62f8e5` |
| sí | `Assets/_Project/Scenes/TestLab.unity` | `002b2ad62af3c614b91e32722c9452be` |

## Anexo I. Documentos consolidados

|---|---:|---|

## Anexo J. Inventario histórico y operativo preservado

Se inventarían **354** fuentes relacionadas con privacidad, legal, Steam, soporte, persistencia, QA, builds, analytics, Cloud y gobernanza. La ausencia de un plan histórico dedicado se conserva como hallazgo: la política previa era condicional y fragmentaria.

|---|---|---|---:|---|

## Anexo K. Definition of Ready / Done

| Sistema | Ready | Done | Estado actual |
|---|---|---|---|
| Privacy baseline | data inventory, roles, owner | RAT, policy and tests | PARTIAL |
| Support | provider, notice, retention, access | request/delete drill | NOT READY |
| Website | host, content, cookie design | scan and policy match | NOT OPEN |
| Steam data | AppID/APIs/permissions | data map and role review | NOT OPEN |
| Steam Cloud | paths, conflict model, legal review | two-device/delete campaign | NOT OPEN |
| Crash reporting | provider and minimized schema | redaction/retention/rights tests | NOT OPEN |
| Telemetry | question, necessity, legal basis | event catalog, UI, kill switch, QA | NOT OPEN |
| Breach response | contacts and templates | timed drill completed | PLANNED |


---
<a id="doc-27-security-and-incident-response-plan"></a>
