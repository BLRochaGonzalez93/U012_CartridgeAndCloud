# 04 Registro Maestro ADR

Esta sección es la ubicación canónica de todas las decisiones arquitectónicas y transversales. Se sitúa después del TDD para que el lector conozca previamente el producto, el alcance y la arquitectura general.

**Estado del registro:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED — última revisión 2026-07-17.

**Regla de autoridad:** ante cualquier conflicto temático, prevalece el ADR de numeración más alta que sustituya expresamente una decisión anterior. Todo cambio futuro exige un ADR nuevo; los identificadores no se reutilizan.

## Índice consolidado de ADR

| ADR | Origen | Decisión | Estado |
|---|---:|---|---|
| [ADR-0001](#adr-0001) | 0 | Unity and Package Baseline | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0002](#adr-0002) | 0 | Version Control and Repository Workflow | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0003](#adr-0003) | 0 | Documentation Baseline and Operational Layer | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0004](#adr-0004) | 0 | Assembly Dependency Boundaries | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0005](#adr-0005) | 0 | Scene Baseline and Global Build Order | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0006](#adr-0006) | 0 | Smoke Test Baseline and Execution Policy | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0007](#adr-0007) | 0 | Windows Development Build Baseline | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0008](#adr-0008) | 0 | Sprint 0 Foundation Closure Policy | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0009](#adr-0009) | 1 | Bootstrap-Owned Scene Flow | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0010](#adr-0010) | 1 | Phase-Level Build Evidence and Release Policy | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0011](#adr-0011) | 2 | Minimal Versioned Save Skeleton | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0012](#adr-0012) | 3 | Scene-Driven Input Contexts | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0013](#adr-0013) | 3 | Direct Planar Click-to-Move Foundation | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0014](#adr-0014) | 3 | Orbit, Zoom and Follow Camera | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0015](#adr-0015) | 3 | Project Input Actions and Context Routing | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0016](#adr-0016) | 4 | Grid Coordinate and Footprint Foundation | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0017](#adr-0017) | 4 | Placement Preview and Rotation | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0018](#adr-0018) | 4 | Atomic Occupancy and Placement Mode | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0019](#adr-0019) | 4 | Sprint 04 Final Integration and Build Gate | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0020](#adr-0020) | 5 | Initial Store Shell Dimensions and Entrance | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0021](#adr-0021) | 5 | Logical Store Access Validation | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0022](#adr-0022) | 5 | Store Placement and Access Integration | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0023](#adr-0023) | 5 | Sprint 05 Final Integration and Build Gate | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0024](#adr-0024) | 6 | Stack and Unit-Capacity Model | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0025](#adr-0025) | 6 | Atomic Inventory Transfers | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0026](#adr-0026) | 6 | Sprint 6 Version and Persistence Boundary | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0027](#adr-0027) | 7 | Product and Supplier Authoring with ScriptableObjects | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0028](#adr-0028) | 7 | Purchase Orders Use Whole Shipment Boxes | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0029](#adr-0029) | 7 | Shipment-Box Receiving Is Atomic | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0030](#adr-0030) | 8 | Single-product display assignment | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0031](#adr-0031) | 8 | Display capacity and visible units | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0032](#adr-0032) | 8 | Atomic manual restocking | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0033](#adr-0033) | 8 | Display authoring and placement boundary | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0034](#adr-0034) | 9 | Selección determinista y cola de spawn | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0035](#adr-0035) | 9 | Ciclo de vida y paciencia | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0036](#adr-0036) | 9 | Límite de navegación técnica | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0037](#adr-0037) | 9 | Límite de población y representación técnica | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0038](#adr-0038) | 10 | Reservation-backed cart | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0039](#adr-0039) | 10 | Deterministic shopping search | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0040](#adr-0040) | 10 | Reservation provenance | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0041](#adr-0041) | 10 | Customer shopping session boundary | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0042](#adr-0042) | 11 | Strict FIFO checkout queue | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0043](#adr-0043) | 11 | Single-entry checkout station | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0044](#adr-0044) | 11 | Preflight then commit checkout | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0045](#adr-0045) | 11 | Checkout idempotency | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0046](#adr-0046) | 12 | Logical Store Day aggregate | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0047](#adr-0047) | 12 | Closing admission gates | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0048](#adr-0048) | 12 | Deterministic drain and resolution | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0049](#adr-0049) | 12 | Closure readiness snapshot | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0050](#adr-0050) | 12 | Technical day summary | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0051](#adr-0051) | 13 | Integer minor-unit money | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0052](#adr-0052) | 13 | Separate sale-price catalog | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0053](#adr-0053) | 13 | Quote before physical checkout | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0054](#adr-0054) | 13 | Idempotent economy ledger | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0055](#adr-0055) | 13 | Closed-day economic result | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0056](#adr-0056) | 14 | Compatible integrated save v2 | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0057](#adr-0057) | 14 | Validated atomic write | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0058](#adr-0058) | 14 | Checksum and generation envelope | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0059](#adr-0059) | 14 | Backup-first recovery | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0060](#adr-0060) | 14 | Two-phase restore | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0061](#adr-0061) | 15 | Runtime UI Composition Root | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0062](#adr-0062) | 15 | Slot UI uses integrated repository | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0063](#adr-0063) | 15 | Closed-day autosave idempotency | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0064](#adr-0064) | 15 | Tutorial progress sidecar | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0065](#adr-0065) | 15 | Global accessibility preferences | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0066](#adr-0066) | 15 | Exclusive UI input | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0067](#adr-0067) | 16 | Sprint 16 two-phase delivery | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0068](#adr-0068) | 16 | Pure Phase 1 sidecar | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0069](#adr-0069) | 16 | Autosave-coordinated checkpoint | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0070](#adr-0070) | 16 | Placement compatibility bridge | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0071](#adr-0071) | 16 | Decoupled presentation fallbacks | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0072](#adr-0072) | 16 | Shared materials and prefab IDs | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0073](#adr-0073) | 16 | Completed checkout snapshot records | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0074](#adr-0074) | DEC-01 | Día H6 configurable de 300 s; velocidades visibles x0,5, x1, x2 y x4; `PauseService` independiente | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0075](#adr-0075) | DEC-02 | `SimulationClock` / `StoreDay` es la única autoridad de tiempo de negocio | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0076](#adr-0076) | DEC-03 | Guardado manual solo desde pausa en `BeforeOpen`, `Closed` o `Results`, sin mutaciones pendientes | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0077](#adr-0077) | DEC-04 | Checkout funcional obligatorio para abrir; no retirar el último durante `Open` | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0078](#adr-0078) | DEC-05 | Máximo H6 configurable de 8 clientes activos; activo = no `Despawned` | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0079](#adr-0079) | DEC-06 | La solicitud reserva fondos; la recepción descuenta caja, registra `SupplierReceivingCost` y añade stock una vez | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0080](#adr-0080) | DEC-07 | `Process All` es todo-o-nada sobre órdenes independientes, reserva el total y crea un `DeliveryRun` | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0081](#adr-0081) | DEC-08 | Displays monoproducto hasta H6; cantidades, retirada, retorno y limpieza de vacío obligatorios | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0082](#adr-0082) | DEC-09 | Management conserva detalle del día actual y los dos completados anteriores; días más antiguos mantienen `DailySummary` individual y acumulados lifetime | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0083](#adr-0083) | DEC-10 | Al cerrar el día 7 se aplica una vez el 10 % de `max(0, resultado bruto técnico semanal)` | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0084](#adr-0084) | DEC-11 | Wall occlusion desactivada mediante feature flag prioritaria; toggle oculto; valores antiguos migrados o ignorados | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0085](#adr-0085) | DEC-12 | Contrato de pivote base-centro mediante wrappers o `GroundAnchor`, con migración/compensación única | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0086](#adr-0086) | 17 | Reloj global continuo y proyección virtual de 24 horas | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0087](#adr-0087) | 17 | Ventana comercial y aperturas múltiples dentro del mismo día | APPROVED / IMPLEMENTED / VALIDATED |
| [ADR-0088](#adr-0088) | 16 | StoreInitial Manual Scene Authoring | APPROVED / IMPLEMENTED / VALIDATED |

## Política de identificación y mantenimiento

- La antigua entrada conflictiva `ADR-0035-S16` se reasigna definitivamente como `ADR-0088`.
- `ADR-0035` conserva exclusivamente la decisión original de Sprint 9 sobre ciclo de vida y paciencia.
- El siguiente identificador disponible es `ADR-0089`.
- Un ADR sustituido conserva su registro con estado `SUPERSEDED` y enlace al ADR sustitutorio.
- Los documentos especializados enlazan a esta sección mediante anclas internas.

<a id="adr-0001"></a>

## ADR-0001 — Unity and Package Baseline

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 0
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 0 requería una regla única para «Unity and Package Baseline», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Unity and Package Baseline.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Unity and Package Baseline».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0002"></a>

## ADR-0002 — Version Control and Repository Workflow

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 0
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 0 requería una regla única para «Version Control and Repository Workflow», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Version Control and Repository Workflow.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Version Control and Repository Workflow».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0003"></a>

## ADR-0003 — Documentation Baseline and Operational Layer

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 0
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 0 requería una regla única para «Documentation Baseline and Operational Layer», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Documentation Baseline and Operational Layer.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Documentation Baseline and Operational Layer».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0004"></a>

## ADR-0004 — Assembly Dependency Boundaries

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 0
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 0 requería una regla única para «Assembly Dependency Boundaries», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Assembly Dependency Boundaries.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Assembly Dependency Boundaries».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0005"></a>

## ADR-0005 — Scene Baseline and Global Build Order

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 0
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 0 requería una regla única para «Scene Baseline and Global Build Order», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Scene Baseline and Global Build Order.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Cerrar la fase sin evidencia reproducible de build y validación.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- La presentación no puede alterar la autoridad del dominio.

### Validación

- La implementación observable coincide con «Scene Baseline and Global Build Order».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0006"></a>

## ADR-0006 — Smoke Test Baseline and Execution Policy

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 0
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 0 requería una regla única para «Smoke Test Baseline and Execution Policy», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Smoke Test Baseline and Execution Policy.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Smoke Test Baseline and Execution Policy».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0007"></a>

## ADR-0007 — Windows Development Build Baseline

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 0
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 0 requería una regla única para «Windows Development Build Baseline», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Windows Development Build Baseline.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Cerrar la fase sin evidencia reproducible de build y validación.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- La presentación no puede alterar la autoridad del dominio.

### Validación

- La implementación observable coincide con «Windows Development Build Baseline».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0008"></a>

## ADR-0008 — Sprint 0 Foundation Closure Policy

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 0
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 0 requería una regla única para «Sprint 0 Foundation Closure Policy», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Sprint 0 Foundation Closure Policy.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Sprint 0 Foundation Closure Policy».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0009"></a>

## ADR-0009 — Bootstrap-Owned Scene Flow

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 1
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 1 requería una regla única para «Bootstrap-Owned Scene Flow», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Bootstrap-Owned Scene Flow.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Bootstrap-Owned Scene Flow».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0010"></a>

## ADR-0010 — Phase-Level Build Evidence and Release Policy

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 1
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 1 requería una regla única para «Phase-Level Build Evidence and Release Policy», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Phase-Level Build Evidence and Release Policy.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Cerrar la fase sin evidencia reproducible de build y validación.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- La presentación no puede alterar la autoridad del dominio.

### Validación

- La implementación observable coincide con «Phase-Level Build Evidence and Release Policy».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0011"></a>

## ADR-0011 — Minimal Versioned Save Skeleton

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 2
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 2 requería una regla única para «Minimal Versioned Save Skeleton», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Minimal Versioned Save Skeleton.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Persistir o restaurar sin versionado, validación o recuperación controlada.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- La compatibilidad y la recuperación de datos forman parte del contrato.

### Validación

- La implementación observable coincide con «Minimal Versioned Save Skeleton».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0012"></a>

## ADR-0012 — Scene-Driven Input Contexts

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 3
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 3 requería una regla única para «Scene-Driven Input Contexts», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Scene-Driven Input Contexts.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- La presentación no puede alterar la autoridad del dominio.

### Validación

- La implementación observable coincide con «Scene-Driven Input Contexts».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0013"></a>

## ADR-0013 — Direct Planar Click-to-Move Foundation

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 3
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 3 requería una regla única para «Direct Planar Click-to-Move Foundation», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Direct Planar Click-to-Move Foundation.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Direct Planar Click-to-Move Foundation».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0014"></a>

## ADR-0014 — Orbit, Zoom and Follow Camera

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 3
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 3 requería una regla única para «Orbit, Zoom and Follow Camera», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Orbit, Zoom and Follow Camera.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- La presentación no puede alterar la autoridad del dominio.

### Validación

- La implementación observable coincide con «Orbit, Zoom and Follow Camera».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0015"></a>

## ADR-0015 — Project Input Actions and Context Routing

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 3
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 3 requería una regla única para «Project Input Actions and Context Routing», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Project Input Actions and Context Routing.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- La presentación no puede alterar la autoridad del dominio.

### Validación

- La implementación observable coincide con «Project Input Actions and Context Routing».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0016"></a>

## ADR-0016 — Grid Coordinate and Footprint Foundation

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 4
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 4 requería una regla única para «Grid Coordinate and Footprint Foundation», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Grid Coordinate and Footprint Foundation.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Grid Coordinate and Footprint Foundation».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0017"></a>

## ADR-0017 — Placement Preview and Rotation

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 4
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 4 requería una regla única para «Placement Preview and Rotation», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Placement Preview and Rotation.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Placement Preview and Rotation».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0018"></a>

## ADR-0018 — Atomic Occupancy and Placement Mode

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 4
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 4 requería una regla única para «Atomic Occupancy and Placement Mode», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Atomic Occupancy and Placement Mode.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Permitir commits parciales o repetidos y compensarlos posteriormente.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- Las operaciones parciales o duplicadas se consideran defectos de integridad.

### Validación

- La implementación observable coincide con «Atomic Occupancy and Placement Mode».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0019"></a>

## ADR-0019 — Sprint 04 Final Integration and Build Gate

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 4
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 4 requería una regla única para «Sprint 04 Final Integration and Build Gate», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Sprint 04 Final Integration and Build Gate.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Cerrar la fase sin evidencia reproducible de build y validación.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- La presentación no puede alterar la autoridad del dominio.

### Validación

- La implementación observable coincide con «Sprint 04 Final Integration and Build Gate».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0020"></a>

## ADR-0020 — Initial Store Shell Dimensions and Entrance

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 5
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 5 requería una regla única para «Initial Store Shell Dimensions and Entrance», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Initial Store Shell Dimensions and Entrance.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Initial Store Shell Dimensions and Entrance».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0021"></a>

## ADR-0021 — Logical Store Access Validation

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 5
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 5 requería una regla única para «Logical Store Access Validation», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Logical Store Access Validation.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Logical Store Access Validation».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0022"></a>

## ADR-0022 — Store Placement and Access Integration

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 5
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 5 requería una regla única para «Store Placement and Access Integration», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Store Placement and Access Integration.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Store Placement and Access Integration».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0023"></a>

## ADR-0023 — Sprint 05 Final Integration and Build Gate

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 5
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 5 requería una regla única para «Sprint 05 Final Integration and Build Gate», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Sprint 05 Final Integration and Build Gate.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Cerrar la fase sin evidencia reproducible de build y validación.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- La presentación no puede alterar la autoridad del dominio.

### Validación

- La implementación observable coincide con «Sprint 05 Final Integration and Build Gate».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0024"></a>

## ADR-0024 — Stack and Unit-Capacity Model

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 6
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 6 requería una regla única para «Stack and Unit-Capacity Model», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Stack and Unit-Capacity Model.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Stack and Unit-Capacity Model».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0025"></a>

## ADR-0025 — Atomic Inventory Transfers

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 6
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 6 requería una regla única para «Atomic Inventory Transfers», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Atomic Inventory Transfers.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Permitir commits parciales o repetidos y compensarlos posteriormente.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- Las operaciones parciales o duplicadas se consideran defectos de integridad.

### Validación

- La implementación observable coincide con «Atomic Inventory Transfers».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0026"></a>

## ADR-0026 — Sprint 6 Version and Persistence Boundary

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 6
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 6 requería una regla única para «Sprint 6 Version and Persistence Boundary», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Sprint 6 Version and Persistence Boundary.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Sprint 6 Version and Persistence Boundary».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0027"></a>

## ADR-0027 — Product and Supplier Authoring with ScriptableObjects

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 7
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 7 requería una regla única para «Product and Supplier Authoring with ScriptableObjects», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Product and Supplier Authoring with ScriptableObjects.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Mantener catálogos dispersos o datos incrustados en escenas y prefabs.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Product and Supplier Authoring with ScriptableObjects».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0028"></a>

## ADR-0028 — Purchase Orders Use Whole Shipment Boxes

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 7
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 7 requería una regla única para «Purchase Orders Use Whole Shipment Boxes», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Purchase Orders Use Whole Shipment Boxes.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Purchase Orders Use Whole Shipment Boxes».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0029"></a>

## ADR-0029 — Shipment-Box Receiving Is Atomic

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 7
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 7 requería una regla única para «Shipment-Box Receiving Is Atomic», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Shipment-Box Receiving Is Atomic.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Permitir commits parciales o repetidos y compensarlos posteriormente.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- Las operaciones parciales o duplicadas se consideran defectos de integridad.

### Validación

- La implementación observable coincide con «Shipment-Box Receiving Is Atomic».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0030"></a>

## ADR-0030 — Single-product display assignment

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 8
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 8 requería una regla única para «Single-product display assignment», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Single-product display assignment.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Single-product display assignment».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0031"></a>

## ADR-0031 — Display capacity and visible units

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 8
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 8 requería una regla única para «Display capacity and visible units», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Display capacity and visible units.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Display capacity and visible units».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0032"></a>

## ADR-0032 — Atomic manual restocking

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 8
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 8 requería una regla única para «Atomic manual restocking», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Atomic manual restocking.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Permitir commits parciales o repetidos y compensarlos posteriormente.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- Las operaciones parciales o duplicadas se consideran defectos de integridad.

### Validación

- La implementación observable coincide con «Atomic manual restocking».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0033"></a>

## ADR-0033 — Display authoring and placement boundary

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 8
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 8 requería una regla única para «Display authoring and placement boundary», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Display authoring and placement boundary.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Display authoring and placement boundary».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0034"></a>

## ADR-0034 — Selección determinista y cola de spawn

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 9
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 9 requería una regla única para «Selección determinista y cola de spawn», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Selección determinista y cola de spawn.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Selección determinista y cola de spawn».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0035"></a>

## ADR-0035 — Ciclo de vida y paciencia

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 9
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 9 requería una regla única para «Ciclo de vida y paciencia», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Ciclo de vida y paciencia.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Ciclo de vida y paciencia».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0036"></a>

## ADR-0036 — Límite de navegación técnica

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 9
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 9 requería una regla única para «Límite de navegación técnica», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Límite de navegación técnica.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Límite de navegación técnica».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0037"></a>

## ADR-0037 — Límite de población y representación técnica

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 9
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 9 requería una regla única para «Límite de población y representación técnica», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Límite de población y representación técnica.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Límite de población y representación técnica».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0038"></a>

## ADR-0038 — Reservation-backed cart

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 10
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 10 requería una regla única para «Reservation-backed cart», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Reservation-backed cart.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Reservation-backed cart».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0039"></a>

## ADR-0039 — Deterministic shopping search

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 10
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 10 requería una regla única para «Deterministic shopping search», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Deterministic shopping search.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Deterministic shopping search».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0040"></a>

## ADR-0040 — Reservation provenance

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 10
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 10 requería una regla única para «Reservation provenance», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Reservation provenance.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Reservation provenance».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0041"></a>

## ADR-0041 — Customer shopping session boundary

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 10
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 10 requería una regla única para «Customer shopping session boundary», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Customer shopping session boundary.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Customer shopping session boundary».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0042"></a>

## ADR-0042 — Strict FIFO checkout queue

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 11
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 11 requería una regla única para «Strict FIFO checkout queue», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Strict FIFO checkout queue.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Strict FIFO checkout queue».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0043"></a>

## ADR-0043 — Single-entry checkout station

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 11
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 11 requería una regla única para «Single-entry checkout station», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Single-entry checkout station.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Single-entry checkout station».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0044"></a>

## ADR-0044 — Preflight then commit checkout

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 11
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 11 requería una regla única para «Preflight then commit checkout», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Preflight then commit checkout.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Preflight then commit checkout».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0045"></a>

## ADR-0045 — Checkout idempotency

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 11
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 11 requería una regla única para «Checkout idempotency», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Checkout idempotency.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Permitir commits parciales o repetidos y compensarlos posteriormente.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- Las operaciones parciales o duplicadas se consideran defectos de integridad.

### Validación

- La implementación observable coincide con «Checkout idempotency».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0046"></a>

## ADR-0046 — Logical Store Day aggregate

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 12
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 12 requería una regla única para «Logical Store Day aggregate», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Logical Store Day aggregate.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Cerrar la fase sin evidencia reproducible de build y validación.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Logical Store Day aggregate».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0047"></a>

## ADR-0047 — Closing admission gates

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 12
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 12 requería una regla única para «Closing admission gates», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Closing admission gates.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Cerrar la fase sin evidencia reproducible de build y validación.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Closing admission gates».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0048"></a>

## ADR-0048 — Deterministic drain and resolution

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 12
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 12 requería una regla única para «Deterministic drain and resolution», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Deterministic drain and resolution.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Deterministic drain and resolution».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0049"></a>

## ADR-0049 — Closure readiness snapshot

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 12
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 12 requería una regla única para «Closure readiness snapshot», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Closure readiness snapshot.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Closure readiness snapshot».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0050"></a>

## ADR-0050 — Technical day summary

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 12
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 12 requería una regla única para «Technical day summary», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Technical day summary.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Technical day summary».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0051"></a>

## ADR-0051 — Integer minor-unit money

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 13
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 13 requería una regla única para «Integer minor-unit money», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Integer minor-unit money.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Integer minor-unit money».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0052"></a>

## ADR-0052 — Separate sale-price catalog

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 13
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 13 requería una regla única para «Separate sale-price catalog», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Separate sale-price catalog.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Separate sale-price catalog».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0053"></a>

## ADR-0053 — Quote before physical checkout

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 13
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 13 requería una regla única para «Quote before physical checkout», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Quote before physical checkout.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Quote before physical checkout».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0054"></a>

## ADR-0054 — Idempotent economy ledger

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 13
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 13 requería una regla única para «Idempotent economy ledger», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Idempotent economy ledger.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Permitir commits parciales o repetidos y compensarlos posteriormente.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- Las operaciones parciales o duplicadas se consideran defectos de integridad.

### Validación

- La implementación observable coincide con «Idempotent economy ledger».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0055"></a>

## ADR-0055 — Closed-day economic result

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 13
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 13 requería una regla única para «Closed-day economic result», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Closed-day economic result.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Closed-day economic result».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0056"></a>

## ADR-0056 — Compatible integrated save v2

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 14
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 14 requería una regla única para «Compatible integrated save v2», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Compatible integrated save v2.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Persistir o restaurar sin versionado, validación o recuperación controlada.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- La compatibilidad y la recuperación de datos forman parte del contrato.

### Validación

- La implementación observable coincide con «Compatible integrated save v2».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0057"></a>

## ADR-0057 — Validated atomic write

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 14
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 14 requería una regla única para «Validated atomic write», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Validated atomic write.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Permitir commits parciales o repetidos y compensarlos posteriormente.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- Las operaciones parciales o duplicadas se consideran defectos de integridad.

### Validación

- La implementación observable coincide con «Validated atomic write».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0058"></a>

## ADR-0058 — Checksum and generation envelope

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 14
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 14 requería una regla única para «Checksum and generation envelope», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Checksum and generation envelope.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Persistir o restaurar sin versionado, validación o recuperación controlada.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Checksum and generation envelope».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0059"></a>

## ADR-0059 — Backup-first recovery

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 14
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 14 requería una regla única para «Backup-first recovery», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Backup-first recovery.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Backup-first recovery».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0060"></a>

## ADR-0060 — Two-phase restore

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 14
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 14 requería una regla única para «Two-phase restore», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Two-phase restore.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Persistir o restaurar sin versionado, validación o recuperación controlada.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- La compatibilidad y la recuperación de datos forman parte del contrato.

### Validación

- La implementación observable coincide con «Two-phase restore».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0061"></a>

## ADR-0061 — Runtime UI Composition Root

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 15
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 15 requería una regla única para «Runtime UI Composition Root», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Runtime UI Composition Root.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- La presentación no puede alterar la autoridad del dominio.

### Validación

- La implementación observable coincide con «Runtime UI Composition Root».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0062"></a>

## ADR-0062 — Slot UI uses integrated repository

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 15
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 15 requería una regla única para «Slot UI uses integrated repository», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Slot UI uses integrated repository.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- La presentación no puede alterar la autoridad del dominio.

### Validación

- La implementación observable coincide con «Slot UI uses integrated repository».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0063"></a>

## ADR-0063 — Closed-day autosave idempotency

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 15
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 15 requería una regla única para «Closed-day autosave idempotency», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Closed-day autosave idempotency.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Permitir commits parciales o repetidos y compensarlos posteriormente.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- Las operaciones parciales o duplicadas se consideran defectos de integridad.
- La compatibilidad y la recuperación de datos forman parte del contrato.

### Validación

- La implementación observable coincide con «Closed-day autosave idempotency».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0064"></a>

## ADR-0064 — Tutorial progress sidecar

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 15
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 15 requería una regla única para «Tutorial progress sidecar», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Tutorial progress sidecar.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Tutorial progress sidecar».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0065"></a>

## ADR-0065 — Global accessibility preferences

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 15
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 15 requería una regla única para «Global accessibility preferences», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Global accessibility preferences.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Global accessibility preferences».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0066"></a>

## ADR-0066 — Exclusive UI input

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 15
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 15 requería una regla única para «Exclusive UI input», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Exclusive UI input.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- La presentación no puede alterar la autoridad del dominio.

### Validación

- La implementación observable coincide con «Exclusive UI input».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0067"></a>

## ADR-0067 — Sprint 16 two-phase delivery

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 16
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 16 requería una regla única para «Sprint 16 two-phase delivery», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Sprint 16 two-phase delivery.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Sprint 16 two-phase delivery».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0068"></a>

## ADR-0068 — Pure Phase 1 sidecar

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 16
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 16 requería una regla única para «Pure Phase 1 sidecar», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Pure Phase 1 sidecar.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Pure Phase 1 sidecar».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0069"></a>

## ADR-0069 — Autosave-coordinated checkpoint

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 16
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 16 requería una regla única para «Autosave-coordinated checkpoint», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Autosave-coordinated checkpoint.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Persistir o restaurar sin versionado, validación o recuperación controlada.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.
- La compatibilidad y la recuperación de datos forman parte del contrato.

### Validación

- La implementación observable coincide con «Autosave-coordinated checkpoint».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0070"></a>

## ADR-0070 — Placement compatibility bridge

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 16
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 16 requería una regla única para «Placement compatibility bridge», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Placement compatibility bridge.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Placement compatibility bridge».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0071"></a>

## ADR-0071 — Decoupled presentation fallbacks

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 16
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 16 requería una regla única para «Decoupled presentation fallbacks», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Decoupled presentation fallbacks.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Decoupled presentation fallbacks».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0072"></a>

## ADR-0072 — Shared materials and prefab IDs

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 16
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 16 requería una regla única para «Shared materials and prefab IDs», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Shared materials and prefab IDs.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Shared materials and prefab IDs».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0073"></a>

## ADR-0073 — Completed checkout snapshot records

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 16
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 16 requería una regla única para «Completed checkout snapshot records», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Completed checkout snapshot records.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Completed checkout snapshot records».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0074"></a>

## ADR-0074 — Día H6 configurable de 300 s; velocidades visibles x0,5, x1, x2 y x4; `PauseService` independiente

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** DEC-01
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen DEC-01 requería una regla única para «Día H6 configurable de 300 s; velocidades visibles x0,5, x1, x2 y x4; `PauseService` independiente», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Día H6 configurable de 300 s; velocidades visibles x0,5, x1, x2 y x4; `PauseService` independiente.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Día H6 configurable de 300 s; velocidades visibles x0,5, x1, x2 y x4; `PauseService` independiente».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0075"></a>

## ADR-0075 — `SimulationClock` / `StoreDay` es la única autoridad de tiempo de negocio

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** DEC-02
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen DEC-02 requería una regla única para «`SimulationClock` / `StoreDay` es la única autoridad de tiempo de negocio», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

`SimulationClock` / `StoreDay` es la única autoridad de tiempo de negocio.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «`SimulationClock` / `StoreDay` es la única autoridad de tiempo de negocio».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0076"></a>

## ADR-0076 — Guardado manual solo desde pausa en `BeforeOpen`, `Closed` o `Results`, sin mutaciones pendientes

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** DEC-03
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen DEC-03 requería una regla única para «Guardado manual solo desde pausa en `BeforeOpen`, `Closed` o `Results`, sin mutaciones pendientes», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Guardado manual solo desde pausa en `BeforeOpen`, `Closed` o `Results`, sin mutaciones pendientes.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Guardado manual solo desde pausa en `BeforeOpen`, `Closed` o `Results`, sin mutaciones pendientes».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0077"></a>

## ADR-0077 — Checkout funcional obligatorio para abrir; no retirar el último durante `Open`

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** DEC-04
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen DEC-04 requería una regla única para «Checkout funcional obligatorio para abrir; no retirar el último durante `Open`», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Checkout funcional obligatorio para abrir; no retirar el último durante `Open`.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Checkout funcional obligatorio para abrir; no retirar el último durante `Open`».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0078"></a>

## ADR-0078 — Máximo H6 configurable de 8 clientes activos; activo = no `Despawned`

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** DEC-05
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen DEC-05 requería una regla única para «Máximo H6 configurable de 8 clientes activos; activo = no `Despawned`», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Máximo H6 configurable de 8 clientes activos; activo = no `Despawned`.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Máximo H6 configurable de 8 clientes activos; activo = no `Despawned`».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0079"></a>

## ADR-0079 — La solicitud reserva fondos; la recepción descuenta caja, registra `SupplierReceivingCost` y añade stock una vez

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** DEC-06
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen DEC-06 requería una regla única para «La solicitud reserva fondos; la recepción descuenta caja, registra `SupplierReceivingCost` y añade stock una vez», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

La solicitud reserva fondos; la recepción descuenta caja, registra `SupplierReceivingCost` y añade stock una vez.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «La solicitud reserva fondos; la recepción descuenta caja, registra `SupplierReceivingCost` y añade stock una vez».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0080"></a>

## ADR-0080 — `Process All` es todo-o-nada sobre órdenes independientes, reserva el total y crea un `DeliveryRun`

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** DEC-07
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen DEC-07 requería una regla única para «`Process All` es todo-o-nada sobre órdenes independientes, reserva el total y crea un `DeliveryRun`», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

`Process All` es todo-o-nada sobre órdenes independientes, reserva el total y crea un `DeliveryRun`.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «`Process All` es todo-o-nada sobre órdenes independientes, reserva el total y crea un `DeliveryRun`».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0081"></a>

## ADR-0081 — Displays monoproducto hasta H6; cantidades, retirada, retorno y limpieza de vacío obligatorios

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** DEC-08
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen DEC-08 requería una regla única para «Displays monoproducto hasta H6; cantidades, retirada, retorno y limpieza de vacío obligatorios», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Displays monoproducto hasta H6; cantidades, retirada, retorno y limpieza de vacío obligatorios.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Displays monoproducto hasta H6; cantidades, retirada, retorno y limpieza de vacío obligatorios».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0082"></a>

## ADR-0082 — Management conserva detalle del día actual y los dos completados anteriores; días más antiguos mantienen `DailySummary` individual y acumulados lifetime

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** DEC-09
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen DEC-09 requería una regla única para «Management conserva detalle del día actual y los dos completados anteriores; días más antiguos mantienen `DailySummary` individual y acumulados lifetime», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Management conserva detalle del día actual y los dos completados anteriores; días más antiguos mantienen `DailySummary` individual y acumulados lifetime.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Management conserva detalle del día actual y los dos completados anteriores; días más antiguos mantienen `DailySummary` individual y acumulados lifetime».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0083"></a>

## ADR-0083 — Al cerrar el día 7 se aplica una vez el 10 % de `max(0, resultado bruto técnico semanal)`

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** DEC-10
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen DEC-10 requería una regla única para «Al cerrar el día 7 se aplica una vez el 10 % de `max(0, resultado bruto técnico semanal)`», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Al cerrar el día 7 se aplica una vez el 10 % de `max(0, resultado bruto técnico semanal)`.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Al cerrar el día 7 se aplica una vez el 10 % de `max(0, resultado bruto técnico semanal)`».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0084"></a>

## ADR-0084 — Wall occlusion desactivada mediante feature flag prioritaria; toggle oculto; valores antiguos migrados o ignorados

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** DEC-11
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen DEC-11 requería una regla única para «Wall occlusion desactivada mediante feature flag prioritaria; toggle oculto; valores antiguos migrados o ignorados», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Wall occlusion desactivada mediante feature flag prioritaria; toggle oculto; valores antiguos migrados o ignorados.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Wall occlusion desactivada mediante feature flag prioritaria; toggle oculto; valores antiguos migrados o ignorados».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0085"></a>

## ADR-0085 — Contrato de pivote base-centro mediante wrappers o `GroundAnchor`, con migración/compensación única

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** DEC-12
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen DEC-12 requería una regla única para «Contrato de pivote base-centro mediante wrappers o `GroundAnchor`, con migración/compensación única», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Contrato de pivote base-centro mediante wrappers o `GroundAnchor`, con migración/compensación única.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Contrato de pivote base-centro mediante wrappers o `GroundAnchor`, con migración/compensación única».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- No consta sustituido en la baseline 0.0.26. Cualquier cambio futuro deberá indicar explícitamente esta relación.

<a id="adr-0086"></a>

## ADR-0086 — Reloj global continuo y proyección virtual de 24 horas

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 17
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 17 requería una regla única para «Reloj global continuo y proyección virtual de 24 horas», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Reloj global continuo y proyección virtual de 24 horas.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Reloj global continuo y proyección virtual de 24 horas».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- Consolida y amplía las decisiones temporales previas, incluida la semántica configurada originalmente en ADR-0074 y ADR-0075.

<a id="adr-0087"></a>

## ADR-0087 — Ventana comercial y aperturas múltiples dentro del mismo día

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 17
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 17 requería una regla única para «Ventana comercial y aperturas múltiples dentro del mismo día», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

Ventana comercial y aperturas múltiples dentro del mismo día.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «Ventana comercial y aperturas múltiples dentro del mismo día».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- Complementa ADR-0086 y sustituye cualquier interpretación de apertura única o liquidación asociada a cierres intermedios.

<a id="adr-0088"></a>

## ADR-0088 — StoreInitial Manual Scene Authoring

- **Estado:** APPROVED / IMPLEMENTED / REVIEWED / VALIDATED
- **Última revisión:** 2026-07-17
- **Origen:** 16
- **Autoridad:** VRM Games / Project Owner

### Contexto

El desarrollo del Sprint/origen 16 requería una regla única para «StoreInitial Manual Scene Authoring», evitando implementaciones divergentes, dependencias implícitas y criterios de validación incompatibles.

### Decisión

StoreInitial Manual Scene Authoring.
Esta decisión constituye el contrato normativo vigente para su ámbito y debe implementarse sin autoridades paralelas ni excepciones implícitas.

### Alternativas consideradas

- Mantener comportamientos ad hoc distribuidos entre sistemas.
- Resolver cada caso mediante configuración o código local sin contrato común.
- Adoptar la decisión consolidada como autoridad única.

### Consecuencias

- Existe una autoridad única que debe reflejarse en código, datos, UX, QA y documentación.
- Las implementaciones posteriores deben mantener compatibilidad o registrar un ADR sustitutorio.
- La validación debe cubrir el flujo nominal, límites, errores y ausencia de efectos duplicados.

### Validación

- La implementación observable coincide con «StoreInitial Manual Scene Authoring».
- No existe una segunda autoridad paralela para la misma responsabilidad.
- Los casos límite y reintentos no producen estados inválidos ni efectos duplicados.
- La documentación especializada referencia este ADR y no reproduce reglas contradictorias.

### Relaciones y sustitución

- Sustituye el alias histórico conflictivo `ADR-0035-S16` sin alterar la autoridad de `ADR-0035`.


---

<a id="doc-04-modelo-de-datos"></a>
